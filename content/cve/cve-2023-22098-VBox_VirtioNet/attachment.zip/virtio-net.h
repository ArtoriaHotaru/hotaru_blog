#include "virtio-pci.h"

/* The feature bitmap for virtio net */
#define VIRTIO_NET_F_CSUM       0       /* Host handles pkts w/ partial csum */
#define VIRTIO_NET_F_GUEST_CSUM 1       /* Guest handles pkts w/ partial csum */
#define VIRTIO_NET_F_MTU        3       /* Initial MTU advice */
#define VIRTIO_NET_F_MAC        5       /* Host has given MAC address. */
#define VIRTIO_NET_F_GSO        6       /* Host handles pkts w/ any GSO type */
#define VIRTIO_NET_F_GUEST_TSO4 7       /* Guest can handle TSOv4 in. */
#define VIRTIO_NET_F_GUEST_TSO6 8       /* Guest can handle TSOv6 in. */
#define VIRTIO_NET_F_GUEST_ECN  9       /* Guest can handle TSO[6] w/ ECN in. */
#define VIRTIO_NET_F_GUEST_UFO  10      /* Guest can handle UFO in. */
#define VIRTIO_NET_F_HOST_TSO4  11      /* Host can handle TSOv4 in. */
#define VIRTIO_NET_F_HOST_TSO6  12      /* Host can handle TSOv6 in. */
#define VIRTIO_NET_F_HOST_ECN   13      /* Host can handle TSO[6] w/ ECN in. */
#define VIRTIO_NET_F_HOST_UFO   14      /* Host can handle UFO in. */
#define VIRTIO_NET_F_MRG_RXBUF  15      /* Driver can merge receive buffers. */
#define VIRTIO_NET_F_STATUS     16      /* Configuration status field is available. */
#define VIRTIO_NET_F_CTRL_VQ    17      /* Control channel is available. */
#define VIRTIO_NET_F_CTRL_RX    18      /* Control channel RX mode support. */
#define VIRTIO_NET_F_CTRL_VLAN  19      /* Control channel VLAN filtering. */
#define VIRTIO_NET_F_GUEST_ANNOUNCE 21  /* Driver can send gratuitous packets. */

#define SetBit(_i) (1<<_i)

struct virtio_net_config { 
    u8 mac[6]; 
    le16 status; 
    le16 max_virtqueue_pairs;
    le16 mtu; 
};

struct virtqueues {
    unsigned int N;
    struct vring *receiveq;
    struct vring *transmitq;
    struct vring *controlq;
};

/*
Packets are transmitted by placing them in the transmitq1…transmitqN,
and buffers for incoming packets are placed in the receiveq1…receiveqN.
In each case, the packet itself is preceded by a header:
*/
struct virtio_net_hdr { 
#define VIRTIO_NET_HDR_F_NEEDS_CSUM    1 
#define VIRTIO_NET_HDR_F_DATA_VALID    2 
#define VIRTIO_NET_HDR_F_RSC_INFO      4 
        u8 flags; 
#define VIRTIO_NET_HDR_GSO_NONE        0 
#define VIRTIO_NET_HDR_GSO_TCPV4       1 
#define VIRTIO_NET_HDR_GSO_UDP         3 
#define VIRTIO_NET_HDR_GSO_TCPV6       4 
#define VIRTIO_NET_HDR_GSO_ECN      0x80 
        u8 gso_type; 
        le16 hdr_len; 
        le16 gso_size; 
        le16 csum_start; 
        le16 csum_offset; 
        le16 num_buffers; 
};

/*
The driver uses the control virtqueue (if VIRTIO_NET_F_CTRL_VQ is negotiated)
to send commands to manipulate various features of the device
which would not easily map into the configuration space.
*/
struct virtio_net_ctrl { 
        u8 class; 
        u8 command; 
        // u8 data[];
        // u8 ack;
};
 
/* ack values */ 
#define VIRTIO_NET_OK     0 
#define VIRTIO_NET_ERR    1

/* VLAN Filtering */
#define VIRTIO_NET_CTRL_VLAN       2 
 #define VIRTIO_NET_CTRL_VLAN_ADD             0 
 #define VIRTIO_NET_CTRL_VLAN_DEL             1

 /* Automatic receive steering in multiqueue mode */
 struct virtio_net_ctrl_mq { 
        le16 virtqueue_pairs; 
}; 
 
/* Both the VIRTIO_NET_CTRL_VLAN_ADD and VIRTIO_NET_CTRL_VLAN_DEL command
   take a little-endian 16-bit VLAN id as the command-specific-data. */
#define VIRTIO_NET_CTRL_VLAN       2 
 #define VIRTIO_NET_CTRL_VLAN_ADD             0 
 #define VIRTIO_NET_CTRL_VLAN_DEL             1

  struct virtio_net_ctrl_vlan { 
        struct virtio_net_ctrl hdr;
        u16 uVlanId;
}; 
