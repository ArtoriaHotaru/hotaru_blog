typedef uint8_t     u8;
typedef uint16_t    u16;
typedef uint32_t    u32;
typedef uint64_t    u64;
typedef uint16_t    le16;
typedef uint32_t    le32;
typedef uint64_t    le64;

/* Status byte for guest to report progress, and synchronize features. */
/* We have seen device and processed generic fields (VIRTIO_CONFIG_F_VIRTIO) */
#define VIRTIO_CONFIG_S_ACKNOWLEDGE     1
/* We have found a driver for the device. */
#define VIRTIO_CONFIG_S_DRIVER          2
/* Driver has used its parts of the config, and is happy */
#define VIRTIO_CONFIG_S_DRIVER_OK       4
/* Driver has finished configuring features */
#define VIRTIO_CONFIG_S_FEATURES_OK     8
/* We've given up on this device. */
#define VIRTIO_CONFIG_S_FAILED          0x80

/* Virtio feature flags used to negotiate device and driver features. */
/* Can the device handle any descriptor layout? */
#define VIRTIO_F_ANY_LAYOUT             27
/* v1.0 compliant. */
#define VIRTIO_F_VERSION_1              32
#define VIRTIO_F_IOMMU_PLATFORM         33

#define MAX_QUEUE_NUM      (256)

#define VRING_DESC_F_NEXT  1
#define VRING_DESC_F_WRITE 2

#define VRING_AVAIL_F_NO_INTERRUPT 1

#define VRING_USED_F_NO_NOTIFY     1

#ifndef VIRTIO_QUEUE_SIZE
   #define VIRTIO_QUEUE_SIZE 0x10
#endif

struct vring_desc {
  u64 addr;
  u32 len;
  u16 flags;
  u16 next;
};

struct vring_avail {
  u16 flags;
  u16 idx;
  u16 ring[VIRTIO_QUEUE_SIZE];
};

struct vring_used_elem {
  u32 id;
  u32 len;
};

struct vring_used {
  u16 flags;
  u16 idx;
  struct vring_used_elem ring[VIRTIO_QUEUE_SIZE];
};

struct vring {
   unsigned int num;
   struct vring_desc *desc;
   struct vring_avail *avail;
   struct vring_used *used;
};

/** Page shift */
#define PAGE_SHIFT 12

/** Page size */
#define PAGE_SIZE ( 1 << PAGE_SHIFT )

/** Page mask */
#define PAGE_MASK ( PAGE_SIZE - 1 )

#define vring_size(num) \
   (((((sizeof(struct vring_desc) * num) + \
      (sizeof(struct vring_avail) + sizeof(u16) * num)) \
         + PAGE_MASK) & ~PAGE_MASK) + \
         (sizeof(struct vring_used) + sizeof(struct vring_used_elem) * num))

/* PCI capability types: */
#define VIRTIO_PCI_CAP_COMMON_CFG       1  /* Common configuration */
#define VIRTIO_PCI_CAP_NOTIFY_CFG       2  /* Notifications */
#define VIRTIO_PCI_CAP_ISR_CFG          3  /* ISR access */
#define VIRTIO_PCI_CAP_DEVICE_CFG       4  /* Device specific configuration */
#define VIRTIO_PCI_CAP_PCI_CFG          5  /* PCI configuration access */

/* This is the PCI capability header: */
struct virtio_pci_cap {
   u8 cap_vndr;    /* Generic PCI field: PCI_CAP_ID_VNDR */
   u8 cap_next;    /* Generic PCI field: next ptr. */
   u8 cap_len;     /* Generic PCI field: capability length */
   u8 cfg_type;    /* Identifies the structure. */
   u8 bar;         /* Where to find it. */
   u8 padding[3];  /* Pad to full dword. */
   le32 offset;    /* Offset within bar. */
   le32 length;    /* Length of the structure, in bytes. */
};

#define VIRTIO_NOTIFY_OFFSET_MULTIPLIER     2                    /**< VirtIO Notify Cap. MMIO config param     */

struct virtio_pci_notify_cap {
   struct virtio_pci_cap cap;
   le32 notify_off_multiplier; /* Multiplier for queue_notify_off. */
};

/* Fields in VIRTIO_PCI_CAP_COMMON_CFG: */
struct virtio_pci_common_cfg {
   /* About the whole device. */
   le32 device_feature_select; /* read-write */
   le32 device_feature;        /* read-only */
   le32 guest_feature_select;  /* read-write */
   le32 guest_feature;         /* read-write */
   le16 msix_config;           /* read-write */
   le16 num_queues;            /* read-only */
   u8 device_status;           /* read-write */
   u8 config_generation;       /* read-only */

      /* About a specific virtqueue. */
   le16 queue_select;          /* read-write */
   le16 queue_size;            /* read-write, power of 2. */
   le16 queue_msix_vector;     /* read-write */
   le16 queue_enable;          /* read-write */
   le16 queue_notify_off;      /* read-only */
   le32 queue_desc_lo;         /* read-write */
   le32 queue_desc_hi;         /* read-write */
   le32 queue_avail_lo;        /* read-write */
   le32 queue_avail_hi;        /* read-write */
   le32 queue_used_lo;         /* read-write */
   le32 queue_used_hi;         /* read-write */
};
