#ifndef CODE_HELPER_H
#define CODE_HELPER_H

#include <stddef.h>

void die(char *fmt, ...);
void success(char *fmt, ...);
void info(char *fmt, ...);
void hex_dump32(void* buf, size_t len);
void hex_dump64(void* buf, size_t len);

#endif /* CODE_HELPER_H */