#ifndef VMSVGA_H
# define VMSVGA_H

#include <stdint.h>
#define u8     uint8_t
#define uint32 uint32_t

/*
 * The data size header following cmdNum for every 3d command
 */
typedef struct {
   uint32               id;
   uint32               size;
} SVGA3dCmdHeader;

/* SVGA_3D_CMD_DEFINE_GB_SURFACE */
#define SVGA_3D_CMD_DEFINE_GB_SURFACE 1097
typedef uint32 SVGA3dSurface1Flags;

/*
 * Surface formats.
 */
typedef enum SVGA3dSurfaceFormat {
   SVGA3D_FORMAT_INVALID               = 0,

   SVGA3D_X8R8G8B8                     = 1,
   SVGA3D_FORMAT_MIN                   = 1,

   SVGA3D_A8R8G8B8                     = 2,

   SVGA3D_R5G6B5                       = 3,
   SVGA3D_X1R5G5B5                     = 4,
   SVGA3D_A1R5G5B5                     = 5,
   SVGA3D_A4R4G4B4                     = 6,

   SVGA3D_Z_D32                        = 7,
   SVGA3D_Z_D16                        = 8,
   SVGA3D_Z_D24S8                      = 9,
   SVGA3D_Z_D15S1                      = 10,

   SVGA3D_LUMINANCE8                   = 11,
   SVGA3D_LUMINANCE4_ALPHA4            = 12,
   SVGA3D_LUMINANCE16                  = 13,
   SVGA3D_LUMINANCE8_ALPHA8            = 14,

   SVGA3D_DXT1                         = 15,
   SVGA3D_DXT2                         = 16,
   SVGA3D_DXT3                         = 17,
   SVGA3D_DXT4                         = 18,
   SVGA3D_DXT5                         = 19,

   SVGA3D_BUMPU8V8                     = 20,
   SVGA3D_BUMPL6V5U5                   = 21,
   SVGA3D_BUMPX8L8V8U8                 = 22,
   SVGA3D_FORMAT_DEAD1                 = 23,

   SVGA3D_ARGB_S10E5                   = 24,   /* 16-bit floating-point ARGB */
   SVGA3D_ARGB_S23E8                   = 25,   /* 32-bit floating-point ARGB */

   SVGA3D_A2R10G10B10                  = 26,

   /* signed formats */
   SVGA3D_V8U8                         = 27,
   SVGA3D_Q8W8V8U8                     = 28,
   SVGA3D_CxV8U8                       = 29,

   /* mixed formats */
   SVGA3D_X8L8V8U8                     = 30,
   SVGA3D_A2W10V10U10                  = 31,

   SVGA3D_ALPHA8                       = 32,

   /* Single- and dual-component floating point formats */
   SVGA3D_R_S10E5                      = 33,
   SVGA3D_R_S23E8                      = 34,
   SVGA3D_RG_S10E5                     = 35,
   SVGA3D_RG_S23E8                     = 36,

   SVGA3D_BUFFER                       = 37,

   SVGA3D_Z_D24X8                      = 38,

   SVGA3D_V16U16                       = 39,

   SVGA3D_G16R16                       = 40,
   SVGA3D_A16B16G16R16                 = 41,

   /* Packed Video formats */
   SVGA3D_UYVY                         = 42,
   SVGA3D_YUY2                         = 43,

   /* Planar video formats */
   SVGA3D_NV12                         = 44,

   SVGA3D_FORMAT_DEAD2                 = 45,

   SVGA3D_R32G32B32A32_TYPELESS        = 46,
   SVGA3D_R32G32B32A32_UINT            = 47,
   SVGA3D_R32G32B32A32_SINT            = 48,
   SVGA3D_R32G32B32_TYPELESS           = 49,
   SVGA3D_R32G32B32_FLOAT              = 50,
   SVGA3D_R32G32B32_UINT               = 51,
   SVGA3D_R32G32B32_SINT               = 52,
   SVGA3D_R16G16B16A16_TYPELESS        = 53,
   SVGA3D_R16G16B16A16_UINT            = 54,
   SVGA3D_R16G16B16A16_SNORM           = 55,
   SVGA3D_R16G16B16A16_SINT            = 56,
   SVGA3D_R32G32_TYPELESS              = 57,
   SVGA3D_R32G32_UINT                  = 58,
   SVGA3D_R32G32_SINT                  = 59,
   SVGA3D_R32G8X24_TYPELESS            = 60,
   SVGA3D_D32_FLOAT_S8X24_UINT         = 61,
   SVGA3D_R32_FLOAT_X8X24              = 62,
   SVGA3D_X32_G8X24_UINT               = 63,
   SVGA3D_R10G10B10A2_TYPELESS         = 64,
   SVGA3D_R10G10B10A2_UINT             = 65,
   SVGA3D_R11G11B10_FLOAT              = 66,
   SVGA3D_R8G8B8A8_TYPELESS            = 67,
   SVGA3D_R8G8B8A8_UNORM               = 68,
   SVGA3D_R8G8B8A8_UNORM_SRGB          = 69,
   SVGA3D_R8G8B8A8_UINT                = 70,
   SVGA3D_R8G8B8A8_SINT                = 71,
   SVGA3D_R16G16_TYPELESS              = 72,
   SVGA3D_R16G16_UINT                  = 73,
   SVGA3D_R16G16_SINT                  = 74,
   SVGA3D_R32_TYPELESS                 = 75,
   SVGA3D_D32_FLOAT                    = 76,
   SVGA3D_R32_UINT                     = 77,
   SVGA3D_R32_SINT                     = 78,
   SVGA3D_R24G8_TYPELESS               = 79,
   SVGA3D_D24_UNORM_S8_UINT            = 80,
   SVGA3D_R24_UNORM_X8                 = 81,
   SVGA3D_X24_G8_UINT                  = 82,
   SVGA3D_R8G8_TYPELESS                = 83,
   SVGA3D_R8G8_UNORM                   = 84,
   SVGA3D_R8G8_UINT                    = 85,
   SVGA3D_R8G8_SINT                    = 86,
   SVGA3D_R16_TYPELESS                 = 87,
   SVGA3D_R16_UNORM                    = 88,
   SVGA3D_R16_UINT                     = 89,
   SVGA3D_R16_SNORM                    = 90,
   SVGA3D_R16_SINT                     = 91,
   SVGA3D_R8_TYPELESS                  = 92,
   SVGA3D_R8_UNORM                     = 93,
   SVGA3D_R8_UINT                      = 94,
   SVGA3D_R8_SNORM                     = 95,
   SVGA3D_R8_SINT                      = 96,
   SVGA3D_P8                           = 97,
   SVGA3D_R9G9B9E5_SHAREDEXP           = 98,
   SVGA3D_R8G8_B8G8_UNORM              = 99,
   SVGA3D_G8R8_G8B8_UNORM              = 100,
   SVGA3D_BC1_TYPELESS                 = 101,
   SVGA3D_BC1_UNORM_SRGB               = 102,
   SVGA3D_BC2_TYPELESS                 = 103,
   SVGA3D_BC2_UNORM_SRGB               = 104,
   SVGA3D_BC3_TYPELESS                 = 105,
   SVGA3D_BC3_UNORM_SRGB               = 106,
   SVGA3D_BC4_TYPELESS                 = 107,
   SVGA3D_ATI1                         = 108,   /* DX9-specific BC4_UNORM */
   SVGA3D_BC4_SNORM                    = 109,
   SVGA3D_BC5_TYPELESS                 = 110,
   SVGA3D_ATI2                         = 111,   /* DX9-specific BC5_UNORM */
   SVGA3D_BC5_SNORM                    = 112,
   SVGA3D_R10G10B10_XR_BIAS_A2_UNORM   = 113,
   SVGA3D_B8G8R8A8_TYPELESS            = 114,
   SVGA3D_B8G8R8A8_UNORM_SRGB          = 115,
   SVGA3D_B8G8R8X8_TYPELESS            = 116,
   SVGA3D_B8G8R8X8_UNORM_SRGB          = 117,

   /* Advanced depth formats. */
   SVGA3D_Z_DF16                       = 118,
   SVGA3D_Z_DF24                       = 119,
   SVGA3D_Z_D24S8_INT                  = 120,

   /* Planar video formats. */
   SVGA3D_YV12                         = 121,

   SVGA3D_R32G32B32A32_FLOAT           = 122,
   SVGA3D_R16G16B16A16_FLOAT           = 123,
   SVGA3D_R16G16B16A16_UNORM           = 124,
   SVGA3D_R32G32_FLOAT                 = 125,
   SVGA3D_R10G10B10A2_UNORM            = 126,
   SVGA3D_R8G8B8A8_SNORM               = 127,
   SVGA3D_R16G16_FLOAT                 = 128,
   SVGA3D_R16G16_UNORM                 = 129,
   SVGA3D_R16G16_SNORM                 = 130,
   SVGA3D_R32_FLOAT                    = 131,
   SVGA3D_R8G8_SNORM                   = 132,
   SVGA3D_R16_FLOAT                    = 133,
   SVGA3D_D16_UNORM                    = 134,
   SVGA3D_A8_UNORM                     = 135,
   SVGA3D_BC1_UNORM                    = 136,
   SVGA3D_BC2_UNORM                    = 137,
   SVGA3D_BC3_UNORM                    = 138,
   SVGA3D_B5G6R5_UNORM                 = 139,
   SVGA3D_B5G5R5A1_UNORM               = 140,
   SVGA3D_B8G8R8A8_UNORM               = 141,
   SVGA3D_B8G8R8X8_UNORM               = 142,
   SVGA3D_BC4_UNORM                    = 143,
   SVGA3D_BC5_UNORM                    = 144,
   SVGA3D_B4G4R4A4_UNORM               = 145,
   
   /* DX11 compressed formats */
   SVGA3D_BC6H_TYPELESS                = 146,
   SVGA3D_BC6H_UF16                    = 147,
   SVGA3D_BC6H_SF16                    = 148,
   SVGA3D_BC7_TYPELESS                 = 149,
   SVGA3D_BC7_UNORM                    = 150,
   SVGA3D_BC7_UNORM_SRGB               = 151,

   /* Video format with alpha */
   SVGA3D_AYUV                         = 152,

   SVGA3D_FORMAT_MAX
} SVGA3dSurfaceFormat;

/*
 * SVGA3D_TEX_FILTER_NONE as the minification filter means mipmapping is
 * disabled, and the rasterizer should use the magnification filter instead.
 */
typedef enum {
   SVGA3D_TEX_FILTER_NONE           = 0,
   SVGA3D_TEX_FILTER_MIN            = 0,
   SVGA3D_TEX_FILTER_NEAREST        = 1,
   SVGA3D_TEX_FILTER_LINEAR         = 2,
   SVGA3D_TEX_FILTER_ANISOTROPIC    = 3,
   SVGA3D_TEX_FILTER_FLATCUBIC      = 4, /* Deprecated, not implemented */
   SVGA3D_TEX_FILTER_GAUSSIANCUBIC  = 5, /* Deprecated, not implemented */
   SVGA3D_TEX_FILTER_PYRAMIDALQUAD  = 6, /* Not currently implemented */
   SVGA3D_TEX_FILTER_GAUSSIANQUAD   = 7, /* Not currently implemented */
   SVGA3D_TEX_FILTER_MAX
} SVGA3dTextureFilter;

typedef struct {
   uint32               width;
   uint32               height;
   uint32               depth;
} SVGA3dSize;

typedef struct SVGA3dCmdDefineGBSurface {
   uint32 sid;
   SVGA3dSurface1Flags surfaceFlags;
   SVGA3dSurfaceFormat format;
   uint32 numMipLevels;
   uint32 multisampleCount;
   SVGA3dTextureFilter autogenFilter;
   SVGA3dSize size;
} SVGA3dCmdDefineGBSurface;   /* SVGA_3D_CMD_DEFINE_GB_SURFACE */

/* SVGA_3D_CMD_DEFINE_GB_SURFACE end */


/* SVGA_3D_CMD_DEFINE_GB_MOB */
#define SVGA_3D_CMD_DEFINE_GB_MOB 1093

typedef uint32 SVGAMobId;

#define SVGA3D_INVALID_ID         ((uint32)-1)
typedef enum SVGAMobFormat {
   SVGA3D_MOBFMT_INVALID     = SVGA3D_INVALID_ID,
   SVGA3D_MOBFMT_PTDEPTH_0   = 0,
   SVGA3D_MOBFMT_MIN         = 0,
   SVGA3D_MOBFMT_PTDEPTH_1   = 1,
   SVGA3D_MOBFMT_PTDEPTH_2   = 2,
   SVGA3D_MOBFMT_RANGE       = 3,
   SVGA3D_MOBFMT_PTDEPTH64_0 = 4,
   SVGA3D_MOBFMT_PTDEPTH64_1 = 5,
   SVGA3D_MOBFMT_PTDEPTH64_2 = 6,
   SVGA3D_MOBFMT_PREDX_MAX   = 7,
   SVGA3D_MOBFMT_EMPTY       = 7,
   SVGA3D_MOBFMT_MAX,

   /*
    * This isn't actually used by the guest, but is a mob-format used
    * internally by the SVGA device (and is therefore not binary compatible).
    */
   SVGA3D_MOBFMT_HB,
} SVGAMobFormat;

typedef uint32 PPN32;

typedef struct SVGA3dCmdDefineGBMob {
   SVGAMobId mobid;
   SVGAMobFormat ptDepth;
   PPN32 base;
   uint32 sizeInBytes;
} SVGA3dCmdDefineGBMob;   /* SVGA_3D_CMD_DEFINE_GB_MOB */

/* SVGA_3D_CMD_DEFINE_GB_MOB end */

/* SVGA_3D_CMD_DESTROY_GB_MOB */
#define SVGA_3D_CMD_DESTROY_GB_MOB 1094

typedef struct SVGA3dCmdDestroyGBMob {
   SVGAMobId mobid;
} SVGA3dCmdDestroyGBMob;   /* SVGA_3D_CMD_DESTROY_GB_MOB */

/* SVGA_3D_CMD_DESTROY_GB_MOB end */

/* SVGA_3D_CMD_BIND_GB_SURFACE */
#define SVGA_3D_CMD_BIND_GB_SURFACE 1099

typedef struct SVGA3dCmdBindGBSurface {
   uint32 sid;
   SVGAMobId mobid;
} SVGA3dCmdBindGBSurface;   /* SVGA_3D_CMD_BIND_GB_SURFACE */

/* SVGA_3D_CMD_BIND_GB_SURFACE end */

/* SVGA_3D_CMD_SURFACE_DMA */
#define SVGA_3D_CMD_SURFACE_DMA 1044

typedef struct SVGAGuestPtr {
   uint32 gmrId;
   uint32 offset;
} SVGAGuestPtr;

typedef struct SVGAGuestImage {
   SVGAGuestPtr         ptr;

   /*
    * A note on interpretation of pitch: This value of pitch is the
    * number of bytes between vertically adjacent image
    * blocks. Normally this is the number of bytes between the first
    * pixel of two adjacent scanlines. With compressed textures,
    * however, this may represent the number of bytes between
    * compression blocks rather than between rows of pixels.
    *
    * XXX: Compressed textures currently must be tightly packed in guest memory.
    *
    * If the image is 1-dimensional, pitch is ignored.
    *
    * If 'pitch' is zero, the SVGA3D device calculates a pitch value
    * assuming each row of blocks is tightly packed.
    */
   uint32 pitch;
} SVGAGuestImage;

typedef struct SVGA3dSurfaceImageId {
   uint32 sid;
   uint32 face;
   uint32 mipmap;
} SVGA3dSurfaceImageId;

typedef enum {
   SVGA3D_WRITE_HOST_VRAM        = 1,
   SVGA3D_READ_HOST_VRAM         = 2,
} SVGA3dTransferType;

typedef struct SVGA3dCopyBox {
   uint32               x;
   uint32               y;
   uint32               z;
   uint32               w;
   uint32               h;
   uint32               d;
   uint32               srcx;
   uint32               srcy;
   uint32               srcz;
} SVGA3dCopyBox;

typedef struct {
   SVGAGuestImage guest;
   SVGA3dSurfaceImageId host;
   SVGA3dTransferType transfer;

   /*
    * Followed by variable number of SVGA3dCopyBox structures. For consistency
    * in all clipping logic and coordinate translation, we define the
    * "source" in each copyBox as the guest image and the
    * "destination" as the host image, regardless of transfer
    * direction.
    *
    * For efficiency, the SVGA3D device is free to copy more data than
    * specified. For example, it may round copy boxes outwards such
    * that they lie on particular alignment boundaries.
    */
} SVGA3dCmdSurfaceDMA;                /* SVGA_3D_CMD_SURFACE_DMA */

/* SVGA_3D_CMD_SURFACE_DMA end */

/* SVGA_3D_CMD_DX_BUFFER_COPY */
#define SVGA_3D_CMD_DX_BUFFER_COPY 1209

typedef uint32 SVGA3dSurfaceId;

typedef struct SVGA3dCmdDXBufferCopy {
   SVGA3dSurfaceId dest;
   SVGA3dSurfaceId src;
   uint32 destX;
   uint32 srcX;
   uint32 width;
} SVGA3dCmdDXBufferCopy;

/* SVGA_3D_CMD_DX_BUFFER_COPY end */

/* SVGA_3D_CMD_DX_READBACK_SUBRESOURCE */
#define SVGA_3D_CMD_DX_READBACK_SUBRESOURCE 1183

typedef struct SVGA3dCmdDXReadbackSubResource {
   SVGA3dSurfaceId sid;
   uint32 subResource;
} SVGA3dCmdDXReadbackSubResource;   /* SVGA_3D_CMD_DX_READBACK_SUBRESOURCE */

/* SVGA_3D_CMD_DX_READBACK_SUBRESOURCE end */

/* SVGA_3D_CMD_DX_DEFINE_CONTEXT */
#define SVGA_3D_CMD_DX_DEFINE_CONTEXT 1143

typedef struct SVGA3dCmdDXDefineContext {
   uint32 cid;
} SVGA3dCmdDXDefineContext;   /* SVGA_3D_CMD_DX_DEFINE_CONTEXT */

/* SVGA_3D_CMD_DX_DEFINE_CONTEXT end */

/* SVGA_3D_CMD_DX_GROW_COTABLE */
#define SVGA_3D_CMD_DX_GROW_COTABLE 1237

/*
 * Guest-backed objects definitions.
 */
typedef enum {
   SVGA_OTABLE_MOB             = 0,
   SVGA_OTABLE_MIN             = 0,
   SVGA_OTABLE_SURFACE         = 1,
   SVGA_OTABLE_CONTEXT         = 2,
   SVGA_OTABLE_SHADER          = 3,
   SVGA_OTABLE_SCREENTARGET    = 4,

   SVGA_OTABLE_DX9_MAX         = 5,

   SVGA_OTABLE_DXCONTEXT       = 5,
   SVGA_OTABLE_DX_MAX          = 6,

   SVGA_OTABLE_RESERVED1       = 6,
   SVGA_OTABLE_RESERVED2       = 7,

   /*
    * Additions to this table need to be tied to HW-version features and
    * checkpointed accordingly.
    */
   SVGA_OTABLE_DEVEL_MAX       = 8,
   SVGA_OTABLE_MAX             = 8
} SVGAOTableType;

typedef enum {
   SVGA_COTABLE_MIN             = 0,
   SVGA_COTABLE_RTVIEW          = 0,
   SVGA_COTABLE_DSVIEW          = 1,
   SVGA_COTABLE_SRVIEW          = 2,
   SVGA_COTABLE_ELEMENTLAYOUT   = 3,
   SVGA_COTABLE_BLENDSTATE      = 4,
   SVGA_COTABLE_DEPTHSTENCIL    = 5,
   SVGA_COTABLE_RASTERIZERSTATE = 6,
   SVGA_COTABLE_SAMPLER         = 7,
   SVGA_COTABLE_STREAMOUTPUT    = 8,
   SVGA_COTABLE_DXQUERY         = 9,
   SVGA_COTABLE_DXSHADER        = 10,
   SVGA_COTABLE_DX10_MAX        = 11,
   SVGA_COTABLE_UAVIEW          = 11,
   SVGA_COTABLE_MAX             = 12,
} SVGACOTableType;

typedef struct SVGA3dCmdDXGrowCOTable {
   uint32 cid;
   uint32 mobid;
   SVGACOTableType type;
   uint32 validSizeInBytes;
} SVGA3dCmdDXGrowCOTable; /* SVGA_3D_CMD_DX_GROW_COTABLE */

/* SVGA_3D_CMD_DX_GROW_COTABLE end */

/* SVGA_3D_CMD_DX_UPDATE_SUBRESOURCE */
#define SVGA_3D_CMD_DX_UPDATE_SUBRESOURCE 1182

typedef struct {
   uint32               x;
   uint32               y;
   uint32               z;
   uint32               w;
   uint32               h;
   uint32               d;
} SVGA3dBox;

typedef struct SVGA3dCmdDXUpdateSubResource {
   SVGA3dSurfaceId sid;
   uint32 subResource;
   SVGA3dBox box;
} SVGA3dCmdDXUpdateSubResource;   /* SVGA_3D_CMD_DX_UPDATE_SUBRESOURCE */

/* SVGA_3D_CMD_DX_UPDATE_SUBRESOURCE end */

/* SVGA_3D_CMD_DX_READBACK_COTABLE */
#define SVGA_3D_CMD_DX_READBACK_COTABLE 1208

typedef struct SVGA3dCmdDXReadbackCOTable {
   uint32 cid;
   SVGACOTableType type;
} SVGA3dCmdDXReadbackCOTable; /* SVGA_3D_CMD_DX_READBACK_COTABLE */

/* SVGA_3D_CMD_DX_READBACK_COTABLE end */

/* SVGA_3D_CMD_SETLIGHTDATA */
#define SVGA_3D_CMD_SETLIGHTDATA 1053
typedef struct {
   uint32               cid;
   uint32               index;
   // SVGA3dLightData     data;
} SVGA3dCmdSetLightData;           /* SVGA_3D_CMD_SETLIGHTDATA */
/* SVGA_3D_CMD_SETLIGHTDATA end */

/* GB_MOB */
/** AVL key type. */
typedef uint32_t    AVLU32KEY;

/** AVL Core node. */
typedef struct _AVLU32NodeCore
{
    struct _AVLU32NodeCore *pLeft;      /**< Pointer to left leaf node. */
    struct _AVLU32NodeCore *pRight;     /**< Pointer to right leaf node. */
    AVLU32KEY               Key;        /**< Key value. */
    unsigned char           uchHeight;  /**< Height of this tree: max(height(left), height(right)) + 1 */
} AVLU32NODECORE;

typedef struct RTLISTNODE
{
    /** Pointer to the next list node. */
    struct RTLISTNODE *pNext;
    /** Pointer to the previous list node. */
    struct RTLISTNODE *pPrev;
} RTLISTNODE;

/** Guest Physical Memory Address.*/
typedef uint64_t                RTGCPHYS;

/* GBO descriptor. */
typedef struct VMSVGAGBODESCRIPTOR
{
   RTGCPHYS                 GCPhys;
   uint64_t                 cPages;
} VMSVGAGBODESCRIPTOR, *PVMSVGAGBODESCRIPTOR;

#define VMSVGAGBO_F_HOST_BACKED     0x2

/* GBO.
 */
typedef struct VMSVGAGBO
{
    uint32_t                fGboFlags;
    uint32_t                cTotalPages;
    uint32_t                cbTotal;
    uint32_t                cDescriptors;
    PVMSVGAGBODESCRIPTOR    paDescriptors;
    void                   *pvHost; /* Pointer to cbTotal bytes on the host if VMSVGAGBO_F_HOST_BACKED is set. */
} VMSVGAGBO;

typedef struct VMSVGAMOB
{
    AVLU32NODECORE          Core; /* Key is the mobid. */
    RTLISTNODE              nodeLRU;
    VMSVGAGBO               Gbo;
} VMSVGAMOB;

/* GB_MOB end */

int define_gb_surface(uint32_t sid, SVGA3dSurfaceFormat format, uint32_t width, uint32_t height, uint32_t depth);
int define_gb_mob(SVGAMobId mobid, uint64_t phys_addr, uint32_t size);
int destroy_gb_mob(SVGAMobId mobid);
int bind_gb_surface(SVGAMobId mobid, uint32_t sid);
int surface_dma(uint32_t sid);
int dx_buffer_copy(uint32_t src_sid, uint32_t dst_sid, uint32_t len);
int dx_readback_subresource(uint32_t sid);
int dx_define_context(uint32_t cid);
int dx_grow_cotable(uint32_t cid, uint32 mobid, SVGACOTableType type, uint32 size);
int dx_update_subresource(uint32_t sid, uint32_t size);
int dx_readback_cotable(uint32_t cid, SVGACOTableType type);
int setlightdata(uint8_t *payload, size_t payload_size);

#endif /* VMSVGA_H */