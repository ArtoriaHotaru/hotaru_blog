#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>

#include "code_helper.h"
#include "dma.h"

int open_vgapwn_dev() {
    int fd = -1;

    fd = open("/dev/vgapwn_dev", O_WRONLY);
    if (fd == -1) {
        die("%s: open faild.", __func__);
    }
    return fd;
}

int dma_alloc(uint64_t size, uint64_t* p_virt_addr, uint64_t* p_phys_addr) {
    int fd = -1;
    fd = open_vgapwn_dev();
    if (fd == -1) {
        die("%s: open_vgapwn_dev faild.", __func__);
        return -1;
    }

    vgapwn_dma_alloc_t args = {
        .size = size,
        .virt_addr = 0,
        .phys_addr = 0
    };
    if (ioctl(fd, VGAPWN_DMA_ALLOC, &args) < 0) {
        die("%s: ioctl VGAPWN_DMA_ALLOC faild.", __func__);
        close(fd);
        return -1;
    }
    *p_virt_addr = args.virt_addr;
    *p_phys_addr = args.phys_addr;
    close(fd);
    return 0;
}

int dma_read(uint64_t size, uint64_t virt_addr, uint8_t *buf_addr) {
    int fd = -1;
    fd = open_vgapwn_dev();
    if (fd == -1) {
        die("%s: open_vgapwn_dev faild.", __func__);
        return -1;
    }

    vgapwn_read_t args = {
        .size = size,
        .src = virt_addr,
        .dst = (uint64_t)buf_addr
    };
    if (ioctl(fd, VGAPWN_DMA_READ, &args) < 0) {
        die("%s: ioctl VGAPWN_DMA_READ faild.", __func__);
        close(fd);
        return -1;
    }
    close(fd);
    return 0;
}

int dma_write(uint64_t size, uint8_t *buf_addr, uint64_t virt_addr) {
    int fd = -1;
    fd = open_vgapwn_dev();
    if (fd == -1) {
        die("%s: open_vgapwn_dev faild.", __func__);
        return -1;
    }

    vgapwn_write_t args = {
        .size = size,
        .src = (uint64_t)buf_addr,
        .dst = virt_addr
    };
    if (ioctl(fd, VGAPWN_DMA_WRITE, &args) < 0) {
        die("%s: ioctl VGAPWN_DMA_WRITE faild.", __func__);
        close(fd);
        return -1;
    }
    close(fd);
    return 0;
}

int dma_free(uint64_t size, uint64_t virt_addr, uint64_t phys_addr) {
    int fd = -1;
    fd = open_vgapwn_dev();
    if (fd == -1) {
        die("%s: open_vgapwn_dev faild.", __func__);
        return -1;
    }

    vgapwn_dma_free_t args = {
        .size = size,
        .virt_addr = virt_addr,
        .phys_addr = phys_addr
    };
    if (ioctl(fd, VGAPWN_DMA_FREE, &args) < 0) {
        die("%s: ioctl VGAPWN_DMA_FREE faild.", __func__);
        close(fd);
        return -1;
    }
    close(fd);
    return 0;
}

int run_cmd(uint8_t *buf, uint64_t size) {
    int fd = -1;
    fd = open_vgapwn_dev();
    if (fd == -1) {
        die("%s: open_vgapwn_dev faild.", __func__);
        return -1;
    }

    vgapwn_run_cmd_t args = {
        .buf = buf,
        .size = size
    };
    if (ioctl(fd, VGAPWN_RUN_CMD, &args) < 0) {
        die("%s: ioctl faild.", __func__);
        close(fd);
        return -1;
    }
    close(fd);
    return 0;
}