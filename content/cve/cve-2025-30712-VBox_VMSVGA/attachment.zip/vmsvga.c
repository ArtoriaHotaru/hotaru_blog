#include <stdlib.h>
#include <string.h>

#include "code_helper.h"
#include "vmsvga.h"
#include "dma.h"

int define_gb_surface(uint32_t sid, SVGA3dSurfaceFormat format, uint32_t width, uint32_t height, uint32_t depth) {
    SVGA3dCmdHeader *pHdr = NULL;
    SVGA3dCmdDefineGBSurface *pCmd = NULL;
    uint8_t *buf = NULL;
    size_t buf_len = sizeof(SVGA3dCmdHeader) + sizeof(SVGA3dCmdDefineGBSurface);

    buf = calloc(buf_len, sizeof(uint8_t));
    pHdr = (SVGA3dCmdHeader *)buf;
    pCmd = (SVGA3dCmdDefineGBSurface *)(&pHdr[1]);

    pHdr->id = SVGA_3D_CMD_DEFINE_GB_SURFACE;
    pHdr->size = sizeof(*pCmd);

    pCmd->sid = sid;
    pCmd->format = format;
    pCmd->numMipLevels = 1;
    pCmd->size.width = width;
    pCmd->size.height = height;
    pCmd->size.depth = depth;

    if (run_cmd(buf, buf_len) < 0) {
        die("%s: run_cmd faild.", __func__);
        return -1;
    }
    free(buf);
    return 0;
}

int define_gb_mob(SVGAMobId mobid, uint64_t phys_addr, uint32_t size) {
    SVGA3dCmdHeader *pHdr = NULL;
    SVGA3dCmdDefineGBMob *pCmd = NULL;
    uint8_t *buf = NULL;
    size_t buf_len = sizeof(SVGA3dCmdHeader) + sizeof(SVGA3dCmdDefineGBMob);

    buf = calloc(buf_len, sizeof(uint8_t));
    pHdr = (SVGA3dCmdHeader *)buf;
    pCmd = (SVGA3dCmdDefineGBMob *)(&pHdr[1]);

    pHdr->id = SVGA_3D_CMD_DEFINE_GB_MOB;
    pHdr->size = sizeof(*pCmd);

    pCmd->mobid = mobid;
    pCmd->base = phys_addr>>12;
    pCmd->ptDepth = SVGA3D_MOBFMT_RANGE;
    pCmd->sizeInBytes = size;

    if (run_cmd(buf, buf_len) < 0) {
        die("%s: run_cmd faild.", __func__);
        return -1;
    }
    free(buf);
    return 0;
}

int destroy_gb_mob(SVGAMobId mobid) {
    SVGA3dCmdHeader *pHdr = NULL;
    SVGA3dCmdDestroyGBMob *pCmd = NULL;
    uint8_t *buf = NULL;
    size_t buf_len = sizeof(SVGA3dCmdHeader) + sizeof(SVGA3dCmdDestroyGBMob);

    buf = calloc(buf_len, sizeof(uint8_t));
    pHdr = (SVGA3dCmdHeader *)buf;
    pCmd = (SVGA3dCmdDestroyGBMob *)(&pHdr[1]);

    pHdr->id = SVGA_3D_CMD_DESTROY_GB_MOB;
    pHdr->size = sizeof(*pCmd);

    pCmd->mobid = mobid;

    if (run_cmd(buf, buf_len) < 0) {
        die("%s: run_cmd faild.", __func__);
        return -1;
    }
    free(buf);
    return 0;
}

int bind_gb_surface(SVGAMobId mobid, uint32_t sid) {
    SVGA3dCmdHeader *pHdr = NULL;
    SVGA3dCmdBindGBSurface *pCmd = NULL;
    uint8_t *buf = NULL;
    size_t buf_len = sizeof(SVGA3dCmdHeader) + sizeof(SVGA3dCmdBindGBSurface);

    buf = calloc(buf_len, sizeof(uint8_t));
    pHdr = (SVGA3dCmdHeader *)buf;
    pCmd = (SVGA3dCmdBindGBSurface *)(&pHdr[1]);

    pHdr->id = SVGA_3D_CMD_BIND_GB_SURFACE;
    pHdr->size = sizeof(*pCmd);

    pCmd->mobid = mobid;
    pCmd->sid = sid;

    if (run_cmd(buf, buf_len) < 0) {
        die("%s: run_cmd faild.", __func__);
        return -1;
    }
    free(buf);
    return 0;
}

int surface_dma(uint32_t sid) {
    SVGA3dCmdHeader *pHdr = NULL;
    SVGA3dCmdSurfaceDMA *pCmd = NULL;
    uint8_t *buf = NULL;
    size_t buf_len = sizeof(SVGA3dCmdHeader) + sizeof(SVGA3dCmdSurfaceDMA);

    buf = calloc(buf_len, sizeof(uint8_t));
    pHdr = (SVGA3dCmdHeader *)buf;
    pCmd = (SVGA3dCmdSurfaceDMA *)(&pHdr[1]);

    pHdr->id = SVGA_3D_CMD_SURFACE_DMA;
    pHdr->size = sizeof(*pCmd);

    pCmd->host.sid = sid;

    if (run_cmd(buf, buf_len) < 0) {
        die("%s: run_cmd faild.", __func__);
        return -1;
    }
    free(buf);
    return 0;
}

int dx_buffer_copy(uint32_t src_sid, uint32_t dst_sid, uint32_t len) {
    SVGA3dCmdHeader *pHdr = NULL;
    SVGA3dCmdDXBufferCopy *pCmd = NULL;
    uint8_t *buf = NULL;
    size_t buf_len = sizeof(SVGA3dCmdHeader) + sizeof(SVGA3dCmdDXBufferCopy);

    buf = calloc(buf_len, sizeof(uint8_t));
    pHdr = (SVGA3dCmdHeader *)buf;
    pCmd = (SVGA3dCmdDXBufferCopy *)(&pHdr[1]);

    pHdr->id = SVGA_3D_CMD_DX_BUFFER_COPY;
    pHdr->size = sizeof(*pCmd);

    pCmd->dest = dst_sid;
    pCmd->src = src_sid;
    pCmd->destX = 0;
    pCmd->srcX = 0;
    pCmd->width = len;

    if (run_cmd(buf, buf_len) < 0) {
        die("%s: run_cmd faild.", __func__);
        return -1;
    }
    free(buf);
    return 0;
}

int dx_readback_subresource(uint32_t sid) {
    SVGA3dCmdHeader *pHdr = NULL;
    SVGA3dCmdDXReadbackSubResource *pCmd = NULL;
    uint8_t *buf = NULL;
    size_t buf_len = sizeof(SVGA3dCmdHeader) + sizeof(SVGA3dCmdDXReadbackSubResource);

    buf = calloc(buf_len, sizeof(uint8_t));
    pHdr = (SVGA3dCmdHeader *)buf;
    pCmd = (SVGA3dCmdDXReadbackSubResource *)(&pHdr[1]);

    pHdr->id = SVGA_3D_CMD_DX_READBACK_SUBRESOURCE;
    pHdr->size = sizeof(*pCmd);

    pCmd->sid = sid;
    pCmd->subResource = 0;

    if (run_cmd(buf, buf_len) < 0) {
        die("%s: run_cmd faild.", __func__);
        return -1;
    }
    free(buf);
    return 0;
}

int dx_define_context(uint32_t cid) {
    SVGA3dCmdHeader *pHdr = NULL;
    SVGA3dCmdDXDefineContext *pCmd = NULL;
    uint8_t *buf = NULL;
    size_t buf_len = sizeof(SVGA3dCmdHeader) + sizeof(SVGA3dCmdDXDefineContext);

    buf = calloc(buf_len, sizeof(uint8_t));
    pHdr = (SVGA3dCmdHeader *)buf;
    pCmd = (SVGA3dCmdDXDefineContext *)(&pHdr[1]);

    pHdr->id = SVGA_3D_CMD_DX_DEFINE_CONTEXT;
    pHdr->size = sizeof(*pCmd);

    pCmd->cid = cid;

    if (run_cmd(buf, buf_len) < 0) {
        die("%s: run_cmd faild.", __func__);
        return -1;
    }
    free(buf);
    return 0;
}

int dx_grow_cotable(uint32_t cid, uint32 mobid, SVGACOTableType type, uint32 size) {
    SVGA3dCmdHeader *pHdr = NULL;
    SVGA3dCmdDXGrowCOTable *pCmd = NULL;
    uint8_t *buf = NULL;
    size_t buf_len = sizeof(SVGA3dCmdHeader) + sizeof(SVGA3dCmdDXGrowCOTable);

    buf = calloc(buf_len, sizeof(uint8_t));
    pHdr = (SVGA3dCmdHeader *)buf;
    pCmd = (SVGA3dCmdDXGrowCOTable *)(&pHdr[1]);

    pHdr->id = SVGA_3D_CMD_DX_GROW_COTABLE;
    pHdr->size = sizeof(*pCmd);

    pCmd->cid = cid;
    pCmd->mobid = mobid;
    pCmd->type = type;
    pCmd->validSizeInBytes = size;

    if (run_cmd(buf, buf_len) < 0) {
        die("%s: run_cmd faild.", __func__);
        return -1;
    }
    free(buf);
    return 0;
}

int dx_update_subresource(uint32_t sid, uint32_t size) {
    SVGA3dCmdHeader *pHdr = NULL;
    SVGA3dCmdDXUpdateSubResource *pCmd = NULL;
    uint8_t *buf = NULL;
    size_t buf_len = sizeof(SVGA3dCmdHeader) + sizeof(SVGA3dCmdDXUpdateSubResource);

    buf = calloc(buf_len, sizeof(uint8_t));
    pHdr = (SVGA3dCmdHeader *)buf;
    pCmd = (SVGA3dCmdDXUpdateSubResource *)(&pHdr[1]);

    pHdr->id = SVGA_3D_CMD_DX_UPDATE_SUBRESOURCE;
    pHdr->size = sizeof(*pCmd);

    pCmd->sid = sid;
    pCmd->subResource = 0;
    pCmd->box.w = size;
    pCmd->box.h = 1;
    pCmd->box.d = 1;

    if (run_cmd(buf, buf_len) < 0) {
        die("%s: run_cmd faild.", __func__);
        return -1;
    }
    free(buf);
    return 0;
}

int dx_readback_cotable(uint32_t cid, SVGACOTableType type) {
    SVGA3dCmdHeader *pHdr = NULL;
    SVGA3dCmdDXReadbackCOTable *pCmd = NULL;
    uint8_t *buf = NULL;
    size_t buf_len = sizeof(SVGA3dCmdHeader) + sizeof(SVGA3dCmdDXReadbackCOTable);

    buf = calloc(buf_len, sizeof(uint8_t));
    pHdr = (SVGA3dCmdHeader *)buf;
    pCmd = (SVGA3dCmdDXReadbackCOTable *)(&pHdr[1]);

    pHdr->id = SVGA_3D_CMD_DX_READBACK_COTABLE;
    pHdr->size = sizeof(*pCmd);

    pCmd->cid = cid;
    pCmd->type = type;

    if (run_cmd(buf, buf_len) < 0) {
        die("%s: run_cmd faild.", __func__);
        return -1;
    }
    free(buf);
    return 0;
}

int setlightdata(uint8_t *payload, size_t payload_size) {
    SVGA3dCmdHeader *pHdr = NULL;
    SVGA3dCmdSetLightData *pCmd = NULL;
    uint8_t *buf = NULL;
    size_t buf_len = sizeof(SVGA3dCmdHeader) + sizeof(SVGA3dCmdSetLightData) + payload_size;

    buf = calloc(buf_len, sizeof(uint8_t));
    pHdr = (SVGA3dCmdHeader *)buf;
    pCmd = (SVGA3dCmdSetLightData *)(&pHdr[1]);

    pHdr->id = SVGA_3D_CMD_SETLIGHTDATA;
    pHdr->size = sizeof(*pCmd) + payload_size;
    memcpy((uint8_t *)&pCmd[1], payload, payload_size);

    if (run_cmd(buf, buf_len) < 0) {
        die("%s: run_cmd faild.", __func__);
        return -1;
    }
    free(buf);
    return 0;
}
