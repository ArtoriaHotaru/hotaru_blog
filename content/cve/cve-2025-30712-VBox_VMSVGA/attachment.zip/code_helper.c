#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdarg.h>

void die(char *fmt, ...) {
    char buf1[0x100] = { 0, };
    char buf2[0x120] = { 0, };
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf1, 0x100, fmt, args);
    va_end(args);

    snprintf(buf2, 0x120, "\033[1;37;41m[ERROR]\033[0m %s", buf1);
    //exit(-1);
}

void success(char *fmt, ...) {
    char buf[0x100] = { 0, };
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, 0x100, fmt, args);
    va_end(args);

    printf("\033[1;32m[+]\033[0m %s\n", buf);
}

void info(char *fmt, ...) {
    char buf[0x100] = { 0, };
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, 0x100, fmt, args);
    va_end(args);

    printf("\033[1;33m[*]\033[0m %s\n", buf);
}

void hex_dump32(void* buf, size_t len) {
    uint32_t *p = (uint32_t *)buf;
    uint8_t *end = (uint8_t *)buf + len;

    puts("=========================================");
    if (len >= 0x10) {
        for (; (uint8_t *)(p+2) <= end; p+=4) {
            printf("%#010x\t%#010x\t%#010x\t%#010x\n", p[0], p[1], p[2], p[3]);
        }
    }
    if (len % 0x10 >= 0xc) {
        printf("%#010x\t%#010x\t%#010x\t", p[0], p[1], p[2]);
        p += 3;
    } else if (len % 0x10 >= 0x8) {
        printf("%#010x\t%#010x\t", p[0], p[1]);
        p += 2;
    } else if (len % 0x10 >= 0x4) {
        printf("%#010x\t", p[0]);
        p += 1;
    }
  
    if (len % 4 > 0) {
        uint32_t tmp = 0;
        for (size_t i = len % 4; i > 0; i--) {
            tmp |= p[i];
            tmp <<= 8;
        }
        printf("%#010x", tmp);
    }
    puts("\n=========================================");
}

void hex_dump64(void* buf, size_t len) {
    uint64_t *p = (uint64_t *)buf;
    uint8_t *end = (uint8_t *)buf + len;

    puts("=====================================");
    if (len >= 0x10) {
        for (; (uint8_t *)(p+2) <= end; p+=2) {
            printf("%#018lx %#018lx\n", p[0], p[1]);
        }
    }
    if (len % 0x10 >= 8) {
        printf("%#018lx ", p[0]);
        p += 1;
    }
  
    if (len % 0x8 > 0) {
        uint64_t tmp = 0;
        for (size_t i = len % 8; i > 0; i--) {
            tmp |= p[i];
            tmp <<= 8;
        }
        printf("%#018lx", tmp);
    }
    puts("\n=====================================");
}
