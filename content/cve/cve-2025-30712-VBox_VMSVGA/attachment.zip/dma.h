#ifndef DMA_H
# define DMA_H

#include <stdint.h>

#define VGAPWN_IOCTL_MAGIC	'k'
#define VGAPWN_DMA_ALLOC	_IOWR(VGAPWN_IOCTL_MAGIC, 0, vgapwn_dma_alloc_t)
#define VGAPWN_DMA_READ		_IOWR(VGAPWN_IOCTL_MAGIC, 1, vgapwn_read_t)
#define VGAPWN_DMA_WRITE	_IOW(VGAPWN_IOCTL_MAGIC, 2, vgapwn_write_t)
#define VGAPWN_DMA_FREE		_IOW(VGAPWN_IOCTL_MAGIC, 3, vgapwn_dma_free_t)
#define VGAPWN_RUN_CMD		_IOW(VGAPWN_IOCTL_MAGIC, 4, vgapwn_run_cmd_t)

typedef struct vgapwn_dma_alloc {
    uint64_t size;
    uint64_t virt_addr;
    uint64_t phys_addr;
} vgapwn_dma_alloc_t;

typedef struct vgapwn_read {
    uint64_t size;
    uint64_t src; // kernel virt_addr
    uint64_t dst; // user   buf_addr
} vgapwn_read_t;

typedef struct vgapwn_write {
    uint64_t size;
    uint64_t src; // user   buf_addr
    uint64_t dst; // kernel virt_addr
} vgapwn_write_t;

typedef struct vgapwn_dma_free {
    uint64_t size;
    uint64_t virt_addr;
    uint64_t phys_addr;
} vgapwn_dma_free_t;

typedef struct vgapwn_run_cmd {
    uint8_t *buf;
    uint64_t size;
} vgapwn_run_cmd_t;

int dma_alloc(uint64_t size, uint64_t* p_virt_addr, uint64_t* p_phys_addr);
int dma_read(uint64_t size, uint64_t virt_addr, uint8_t *buf_addr);
int dma_write(uint64_t size, uint8_t *buf_addr, uint64_t virt_addr);
int dma_free(uint64_t size, uint64_t virt_addr, uint64_t phys_addr);
int run_cmd(uint8_t *buf, uint64_t size);

#endif /* DMA_H */
