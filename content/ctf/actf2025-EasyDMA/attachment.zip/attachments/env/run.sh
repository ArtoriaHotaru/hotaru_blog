#!/bin/sh
timeout --foreground 300 ./qemu-system-x86_64 \
    -L pc-bios \
    -m 1024 \
    -kernel bzImage \
    -initrd rootfs.cpio \
    -drive file=null-co://,if=none,id=mydisk \
    -device virtio-blk-pci,drive=mydisk,ioeventfd=off \
    -device readflag \
    -append "priority=low console=ttyS0" \
    -monitor /dev/null \
    -nographic
