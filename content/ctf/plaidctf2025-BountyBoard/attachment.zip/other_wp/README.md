

Xion *—* 昨天05:10

Bounty Board, the problematic part:

* memcpy with negative size may cause controlled offset writes on optimized implementations, where what implementation is chosen is decided by the cpu type (vendor) and cpu features that the environment has through ifunc resolution.
* The local & remote environment may be different, and also very well be the same. However, this does not require explicit guesses or multiple different implementations of the full exploit.
* The remote environment behavior can be probed by observable differences between the memcpy implementations. For example, `ssse3`, `sse2`, `avx` & `evex`, and `avx512` will copy 0x30, 0x40, 0x80, and 0x100 respectively to the destination address if given a negative size. Players can use this to check whether the top chunk has been corrupted or not by copying to the adjacent chunk and trying to allocate next chunk. Similarly, copying to negative offsets also work due to differences in unit copy size.

Xion *—* 昨天05:14

* Overwrite top chunk to a smaller but page-aligned size
* Send "00000.....1" or something in the lines of this to scanf to try to allocate 0x800 sized chunk which fails to allocate at top chunk, frees it into unsorted bin and thus writing a libc address on the heap
* Copy this over to tcache_perthread_struct, partial overwrite to stdout and allocate there to leak pointers, then fsop

iirc this should be something like https://corgi.rip/posts/leakless_heap_1/(已编辑)

Xion *—* 昨天05:36

some of the intel cpus do support avx512 but do not have the avx_vnni capability which glibc decides on blocking the use of avx512 likely due to underclocking issues. if this is the case, `glibc.cpu.hwcaps` might help... somewhat.

### a$h *—* 昨天05:16

this was my solve for bounty board.

* used overflow to shrink the size of the top chunk
* use large scanf mallocs to trigger sysmalloc `_int_free`, and get unsortedbin chunks on the heap
* partially overwrite libc pointer to `_IO_2_1_stdout_`
* use negative size memcpy to copy this pointer backwards into `tcache_perthread_struct`, as well as a valid tcache count
* FSOP for leak
* same idea to move a pointer into tcache_perthread_struct, allocating on stdout again, this time for RCE

https://discord.com/channels/832061075670302732/1358547257720307973/1358550916231594004