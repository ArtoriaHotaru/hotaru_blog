# README

## Build

```
docker build -t babybus .
```

## Run

```
docker run -e ICQ_FLAG=flag{fake_flag} -it --rm --name babybus -p 1502:1502 babybus
```
