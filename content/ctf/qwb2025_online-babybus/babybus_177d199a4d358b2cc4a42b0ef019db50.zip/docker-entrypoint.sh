#!/usr/bin/env sh
#!/bin/bash

FLAG_PATH=/home/ctf/flag
FLAG_MODE=M_ECHO
if [ ${ICQ_FLAG} ];then
    case $FLAG_MODE in
        "M_ECHO")
            echo -n ${ICQ_FLAG} > ${FLAG_PATH}
            FILE_MODE=755 # 注意这里的权限，flag的权限一定要注意，是所有用户可读，还是只有root可读
            chmod ${FILE_MODE} ${FLAG_PATH}
            ;;
        "M_SED")
            #sed -i "s/flag{x*}/${ICQ_FLAG}/" ${FLAG_PATH}
            sed -i -r "s/flag\{.*\}/${ICQ_FLAG}/" ${FLAG_PATH}
            ;;
        "M_SQL")
            # sed -i -r "s/flag\{.*\}/${ICQ_FLAG}/" ${FLAG_PATH}
            # mysql -uroot -proot < ${FLAG_PATH}
            ;;
        *)
            ;;
    esac
    echo [+] ICQ_FLAG OK
    unset ICQ_FLAG
else
    echo [!] no ICQ_FLAG
fi

#del eci env
rm -rf /etc/profile.d/pouchenv.sh
rm -rf /etc/instanceInfo

# sth

set -eu

# 环境参数
HOST="${HOST:-0.0.0.0}"
PORT="${PORT:-1502}"
RESTART_DELAY="${RESTART_DELAY:-1}"
UNIT_ID="${UNIT_ID:-1}"
TIMER_RESTART="${TIMER_RESTART:-20}"


GEN_RUN="/home/ctf/run.sh"

trap 'echo "[entrypoint] received signal, exiting"; exit 0' INT TERM


start_time=$(date +%s)
while true; do
  echo "[entrypoint] starting QEMU on ${HOST}:${PORT}"
  

  if [ "${TIMER_RESTART}" -gt 0 ]; then
    echo "[entrypoint] timer restart enabled: ${TIMER_RESTART}s"
    set +e
    timeout "${TIMER_RESTART}" "${GEN_RUN}"
    exit_code=$?
    set -e
    
    current_time=$(date +%s)
    runtime=$((current_time - start_time))
    
    if [ $exit_code -eq 124 ]; then
      # timeout命令的退出码124表示超时
      echo "[entrypoint] qemu timed out after ${TIMER_RESTART}s (runtime: ${runtime}s), restarting"
    else
      echo "[entrypoint] qemu exited with code ${exit_code} after ${runtime}s, restart in ${RESTART_DELAY}s"
      sleep "${RESTART_DELAY}"
    fi
  else
    # 仅错误重启模式
    set +e
    "${GEN_RUN}"
    exit_code=$?
    set -e
    
    current_time=$(date +%s)
    runtime=$((current_time - start_time))
    echo "[entrypoint] qemu exited with code ${exit_code} after ${runtime}s, restart in ${RESTART_DELAY}s"
    sleep "${RESTART_DELAY}"
  fi
  
  # 重置开始时间
  start_time=$(date +%s)
done