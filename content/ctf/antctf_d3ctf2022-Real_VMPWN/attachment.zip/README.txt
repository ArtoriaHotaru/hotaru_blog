宿主机安装了 vmware (安装包见附件)，并使用附件中的 vmnet-dhcpd 替换了 /usr/bin/vmnet-dhcpd
宿主机安装了一台用 vmware 运行的客户机 ，选手连接环境后，将得到客户机的 shell

在客户机利用漏洞使得宿主机执行 /gflag 后，flag 会出现在客户机上的 /flag 

同一时间，只能有一个队伍挑战题目，且每个队伍仅有两次机会

建议使用命令 "socat file:`tty`,raw,echo=0 tcp:IP:PORT"，这将获得客户机的一个 tty 交互式 shell

The host has installed vmware (see attachment for the installation package), and replaced /usr/bin/vmnet-dhcpd with vmnet-dhcpd in the attachment
The host computer installs a client machine running with vmware. After connecting to the environment, the contestant will get the client's shell

At the same time, only one team can try the challenge, and each team has only two opportunities.

It is recommended to use the command "socat file:`tty`,raw,echo=0 tcp:IP:PORT", which will get a tty shell of the client.

After exploiting the vulnerability to execute "/gflag" on the host, the "/flag" file on the client is the flag

